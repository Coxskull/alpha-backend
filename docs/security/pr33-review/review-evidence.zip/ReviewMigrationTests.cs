using Alpha.API.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql;
using Xunit;

namespace Alpha.API.Integration.Tests;

[Collection("Disposable PostgreSQL")]
public sealed class ReviewMigrationTests(DatabaseFixture fixture)
{
    [Fact]
    public async Task ReviewProbeHistoryMigrationDowngradeAndReapplyPreserveRowsAndRestoreGuards()
    {
        using var db = fixture.Context();
        var audit = new AuditLog { Id = Guid.NewGuid(), OrderId = Guid.NewGuid(), Action = "roundtrip original", PerformedBy = "review", CreatedAt = DateTime.UtcNow };
        db.Add(audit); await db.SaveChangesAsync();
        var migrator = db.GetService<IMigrator>();
        try
        {
            await migrator.MigrateAsync("20261012071522_AttributedRefundRecovery");
            Assert.DoesNotContain("20261012120000_FinancialAuditIntegrity", await db.Database.GetAppliedMigrationsAsync());
            Assert.Equal("roundtrip original", (await db.AuditLogs.AsNoTracking().SingleAsync(a => a.Id == audit.Id)).Action);
        }
        finally { await migrator.MigrateAsync(); }
        Assert.Contains("20261012120000_FinancialAuditIntegrity", await db.Database.GetAppliedMigrationsAsync());
        var error = await Assert.ThrowsAsync<PostgresException>(() => db.Database.ExecuteSqlInterpolatedAsync($"UPDATE audit_logs SET action = 'changed' WHERE id = {audit.Id}"));
        Assert.Equal("23514", error.SqlState);
        Assert.Equal("roundtrip original", (await db.AuditLogs.AsNoTracking().SingleAsync(a => a.Id == audit.Id)).Action);
    }
}
