using Alpha.API.Data;
using Alpha.API.Models;
using Alpha.API.Models.Entrepreneur;
using Alpha.API.DTOs;
using Alpha.API.Services;
using Microsoft.EntityFrameworkCore;
using Npgsql;
using System.Text.Json;

var output = Path.GetFullPath(args[0]);
var baseline = JsonDocument.Parse(File.ReadAllText(Path.Combine(output, "baseline.json")));
Guid Id(string key) => baseline.RootElement.GetProperty("ids").GetProperty(key).GetGuid();
string mode = args[1];
string database = mode == "restore" ? "alpha_stage_restored" : "alpha_stage_rehearsal";
AppDbContext Context() => new(new DbContextOptionsBuilder<AppDbContext>().UseNpgsql(
    $"Host=127.0.0.1;Port=5432;Database={database};Username=alpha_ci;Password=disposable-ci-only;SSL Mode=Disable").Options);
void Require(bool condition, string message) { if (!condition) throw new InvalidOperationException(message); }
async Task Snapshot(AppDbContext context, string name)
{
    var tables = new[] { "orders", "payments", "order_financials", "suppliers", "supplier_payouts", "settlement_queue", "payment_operations", "refund_allocations", "payout_recovery_offsets", "audit_logs", "entrepreneur_payout_batches" };
    var rows = new SortedDictionary<string, string>();
    // Table identifiers come exclusively from the constant allowlist above.
#pragma warning disable EF1002
    foreach (var table in tables)
        rows[table] = await context.Database.SqlQueryRaw<string>($"SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text), '[]'::jsonb)::text AS \"Value\" FROM {table} t").SingleAsync();
#pragma warning restore EF1002
    File.WriteAllText(Path.Combine(output, name), JsonSerializer.Serialize(rows, new JsonSerializerOptions { WriteIndented = true }));
}
var historicalBatch = Id("historicalBatch");
var conflictPayment = Id("conflictPayment");
var validPayment = Id("validPayment");
var conflictAllocation = Id("conflictAllocation");
var validAllocation = Id("validAllocation");
var validFutureOrder = Id("validFutureOrder");
using var db = Context();
if (mode == "upgrade")
{
    var beforePayments = await db.Database.SqlQueryRaw<decimal>("SELECT SUM(refunded_amount) AS \"Value\" FROM payments").SingleAsync();
    var beforePaid = await db.SupplierPayouts.SumAsync(p => p.Amount);
    await db.Database.MigrateAsync();
    Require((await db.Database.GetAppliedMigrationsAsync()).Count() == 9, "Expected nine applied migrations.");
    Require((await SchemaComparison.CompareAsync(db)).Count == 0, "Schema/model parity failed.");
    Require(await db.Payments.SumAsync(p => p.RefundedAmount) == beforePayments, "Upgrade changed customer refund totals.");
    Require(await db.SupplierPayouts.SumAsync(p => p.Amount) == beforePaid, "Upgrade changed historical payouts.");
    Require((await db.EntrepreneurPayoutBatches.SingleAsync(b => b.Id == historicalBatch)).TotalAmount == 40.25m, "Historical batch changed.");
    Require((await db.Payments.SingleAsync(p => p.Id == conflictPayment)).RefundEvidenceConflict, "Audited legacy conflict was not backfilled.");
    Require(!(await db.Payments.SingleAsync(p => p.Id == validPayment)).RefundEvidenceConflict, "Unrelated valid source was held.");
    await db.Database.ExecuteSqlRawAsync("""
        CREATE ROLE alpha_stage_runtime NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE NOREPLICATION;
        GRANT USAGE ON SCHEMA public TO alpha_stage_runtime;
        GRANT SELECT ON ALL TABLES IN SCHEMA public TO alpha_stage_runtime;
        GRANT UPDATE ON payments, order_financials, settlement_queue TO alpha_stage_runtime;
        GRANT UPDATE (recovered_amount) ON refund_allocations TO alpha_stage_runtime;
        GRANT INSERT ON supplier_payouts, driver_payouts, payout_recovery_offsets, audit_logs TO alpha_stage_runtime;
        """);
    await db.Database.OpenConnectionAsync();
    await db.Database.ExecuteSqlRawAsync("SET ROLE alpha_stage_runtime");
    Require(await db.Database.SqlQueryRaw<string>("SELECT current_user::text AS \"Value\"").SingleAsync() == "alpha_stage_runtime", "Runtime role was not selected.");
    async Task RejectSql(string sql, string expected)
    {
        try { await db.Database.ExecuteSqlRawAsync(sql); throw new InvalidOperationException("Unsafe SQL unexpectedly succeeded."); }
        catch (PostgresException ex) { Require(ex.SqlState == expected, $"Wrong rejection class: expected {expected}, actual {ex.SqlState}; SQL {sql}."); }
    }
    await RejectSql("ALTER TABLE audit_logs DISABLE TRIGGER ALL", "42501");
    await RejectSql("SET session_replication_role = replica", "42501");
    await RejectSql("CREATE TABLE runtime_unauthorized_table(id int)", "42501");
    await RejectSql("UPDATE audit_logs SET action = 'changed'", "42501");
    await RejectSql($"UPDATE payments SET refund_evidence_conflict = FALSE WHERE id = '{Id("conflictPayment")}'", "23514");
    try
    {
        await new PayoutAccountingService(db).SettlementAsync(Id("conflictFutureQueue"), new PayoutConfirmationDto { PaidAmount = 20, Currency = "USD", PayoutReference = "synthetic-held-attempt" }, Id("reviewer"), null, CancellationToken.None);
        throw new InvalidOperationException("Conflicted recovery unexpectedly succeeded.");
    }
    catch (InvalidOperationException ex) when (ex.Message.Contains("Recovery is held")) { }
    Require((await db.Set<RefundAllocation>().SingleAsync(a => a.Id == conflictAllocation)).RecoveredAmount == 0, "Held claim was consumed.");
    await new PayoutAccountingService(db).SettlementAsync(Id("validFutureQueue"), new PayoutConfirmationDto { PaidAmount = 40, Currency = "USD", PayoutReference = "synthetic-runtime-net" }, Id("reviewer"), null, CancellationToken.None);
    Require((await db.Set<RefundAllocation>().SingleAsync(a => a.Id == validAllocation)).RecoveredAmount == 10, "Valid recovery amount incorrect.");
    Require((await db.SupplierPayouts.SingleAsync(p => p.OrderId == validFutureOrder)).Amount == 40, "Net runtime payout amount incorrect.");
    var mutationChecks = new List<object>();
    async Task CheckedReject(string sql, string expected)
    {
        await RejectSql(sql, expected);
        mutationChecks.Add(new { sql, expectedSqlState = expected, result = "REJECTED" });
    }
    foreach (var table in new[] { "audit_logs", "payout_recovery_offsets", "refund_allocations" })
    {
        await CheckedReject("DELETE FROM " + table, "42501");
        await CheckedReject("TRUNCATE TABLE " + table + " CASCADE", "42501");
    }
    await CheckedReject("UPDATE payout_recovery_offsets SET amount = amount + 1", "42501");
    await CheckedReject("UPDATE refund_allocations SET recovered_amount = 0 WHERE recovered_amount > 0", "23514");
    await CheckedReject("CREATE OR REPLACE FUNCTION reject_financial_history_change() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN RETURN NEW; END $$", "42501");
    await CheckedReject("DROP TRIGGER audit_logs_append_only ON audit_logs", "42501");
    await db.Database.ExecuteSqlRawAsync("RESET ROLE");
    // Owner has DML rights; these assertions exercise actual triggers, not missing grants.
    foreach (var table in new[] { "audit_logs", "payout_recovery_offsets", "refund_allocations" })
    {
        await CheckedReject("DELETE FROM " + table, "23514");
        await CheckedReject("TRUNCATE TABLE " + table + " CASCADE", "23514");
    }
    await CheckedReject("UPDATE audit_logs SET action = 'changed'", "23514");
    await CheckedReject("UPDATE payout_recovery_offsets SET amount = amount + 1", "23514");
    await CheckedReject("UPDATE refund_allocations SET recovered_amount = 0 WHERE recovered_amount > 0", "23514");
    File.WriteAllText(Path.Combine(output, "history-mutation-checks.json"), JsonSerializer.Serialize(mutationChecks, new JsonSerializerOptions { WriteIndented = true }));

    await Snapshot(db, "before-backup-business-state.json");
    File.WriteAllText(Path.Combine(output, "upgrade-result.json"), JsonSerializer.Serialize(new { upgrade = "PASS", schemaParity = "PASS", appliedMigrations = 9, historicalMoneyPreserved = true, conflictBackfill = "PASS", unrelatedSourceUnheld = true, runtimeRole = "alpha_stage_runtime", runtimeDDLAndHistoryMutation = "REJECTED", conflictedRecovery = "BLOCKED", validRecovery = 10, validNetPayout = 40, scope = "Synthetic local upgrade only; runtime permissions are a rehearsal template" }, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine("UPGRADE/RUNTIME PASS: historical money preserved; conflict backfill and least-privilege held/valid recovery verified.");
}
else if (mode == "restore")
{
    Require((await SchemaComparison.CompareAsync(db)).Count == 0, "Restored schema/model parity failed.");
    Require((await db.Database.GetAppliedMigrationsAsync()).Count() == 9, "Restored migration history differs.");
    await Snapshot(db, "restored-business-state.json");
    Require(File.ReadAllText(Path.Combine(output, "before-backup-business-state.json")) == File.ReadAllText(Path.Combine(output, "restored-business-state.json")), "Restored business rows differ.");
    try { await db.Database.ExecuteSqlInterpolatedAsync($"UPDATE payments SET refund_evidence_conflict = FALSE WHERE id = {Id("conflictPayment")}"); throw new InvalidOperationException("Restored conflict guard missing."); }
    catch (PostgresException ex) { Require(ex.SqlState == "23514", "Restored guard returned wrong rejection."); }
    foreach (var table in new[] { "audit_logs", "payout_recovery_offsets", "refund_allocations" })
    {
        foreach (var command in new[] { "DELETE FROM " + table, "TRUNCATE TABLE " + table + " CASCADE" })
        {
            try { await db.Database.ExecuteSqlRawAsync(command); throw new InvalidOperationException("Restored history guard missing."); }
            catch (PostgresException ex) { Require(ex.SqlState == "23514", "Wrong restored history rejection."); }
        }
    }
    await Snapshot(db, "restored-after-rejected-mutations.json");
    Require(File.ReadAllText(Path.Combine(output, "restored-business-state.json")) == File.ReadAllText(Path.Combine(output, "restored-after-rejected-mutations.json")), "Rejected mutations altered history.");
    File.WriteAllText(Path.Combine(output, "restore-result.json"), JsonSerializer.Serialize(new { restore = "PASS", businessRowsMatch = true, migrations = 9, schemaParity = "PASS", conflictGuardRestored = true, scope = "Synthetic backup only; no hosted baseline or real records" }, new JsonSerializerOptions { WriteIndented = true }));
    Console.WriteLine("RESTORE PASS: business rows, migration history, model and durable guard match.");
}
else throw new ArgumentException("Unsupported fixed rehearsal mode.");
