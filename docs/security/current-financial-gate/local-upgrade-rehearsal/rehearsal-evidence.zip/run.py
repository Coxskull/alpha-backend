import os, subprocess, pathlib, json, time, hashlib
root=pathlib.Path('/workspace/work/acceptance-rehearsal'); out=root/'evidence'
env=os.environ.copy()
for k in list(env):
 if any(s in k.lower() for s in ('database','supabase','jwt','paypal','stripe','paymongo','connectionstrings')): del env[k]
env.update(PATH='/workspace/.dotnet:'+env['PATH'],DOTNET_ROOT='/workspace/.dotnet',DOTNET_CLI_HOME='/workspace/.dotnet-home',NUGET_PACKAGES='/workspace/.nuget/packages',DOTNET_CLI_TELEMETRY_OPTOUT='1')
results=[]
def run(name,args):
 start=time.time(); p=subprocess.run(args,env=env,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=600)
 (out/(name+'.log')).write_text('COMMAND '+json.dumps(args)+'\n'+p.stdout)
 results.append(dict(check=name,exitCode=p.returncode,seconds=round(time.time()-start,2))); (out/'execution.json').write_text(json.dumps(results,indent=2)); print(name,p.returncode,flush=True)
 if p.returncode: raise RuntimeError(p.stdout[-5000:])
 return p.stdout
container='alpha-acceptance-rehearsal'
def sql(name,db,query): return run(name,['docker','exec',container,'psql','-U','alpha_ci','-d',db,'-At','-v','ON_ERROR_STOP=1','-c',query]).strip()
tables=['orders','payments','order_financials','suppliers','supplier_payouts','settlement_queue','payment_operations','refund_allocations','payout_recovery_offsets','audit_logs','entrepreneur_payout_batches']
def snapshot(db,label):
 value={t:sql(label+'-'+t,db,f"SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text),'[]'::jsonb)::text FROM {t} t") for t in tables}
 (out/(label+'.json')).write_text(json.dumps(value,sort_keys=True,indent=2)); return value
try:
 run('baseline-identity',['git','-C','/workspace/work/acceptance-base','rev-parse','HEAD'])
 run('candidate-identity',['git','-C','/workspace/work/current-financial-gate','rev-parse','HEAD'])
 run('postgres-start',['docker','run','-d','--name',container,'-p','127.0.0.1:5432:5432','-e','POSTGRES_USER=alpha_ci','-e','POSTGRES_PASSWORD=disposable-ci-only','-e','POSTGRES_DB=alpha_stage_rehearsal','postgres:16@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d'])
 for i in range(30):
  p=subprocess.run(['docker','exec',container,'pg_isready','-U','alpha_ci'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  if p.returncode==0: break
  time.sleep(1)
 for name in ('base','candidate'):
  project=str(root/name/('Rehearsal.'+('Base' if name=='base' else 'Candidate')+'.csproj'))
  run(name+'-restore',['dotnet','restore',project])
  run(name+'-build',['dotnet','build',project,'-c','Release','--no-restore','-warnaserror'])
 run('baseline-seed',['dotnet','run','--project',str(root/'base'),'--no-build','--no-restore','-c','Release','--',str(out/'baseline.json')])
 before=snapshot('alpha_stage_rehearsal','baseline-before-backup')
 for stage,target in [('baseline','alpha_stage_baseline_restored'),('upgraded','alpha_stage_restored')]:
  if stage=='upgraded': run('upgrade-runtime',['dotnet','run','--project',str(root/'candidate'),'--no-build','--no-restore','-c','Release','--',str(out),'upgrade'])
  run(stage+'-dump',['docker','exec',container,'pg_dump','-U','alpha_ci','-d','alpha_stage_rehearsal','-Fc','--no-owner','--no-privileges','-f','/tmp/'+stage+'.dump'])
  run(stage+'-dump-copy',['docker','cp',container+':/tmp/'+stage+'.dump',str(out/(stage+'.dump'))])
  sql(stage+'-create-restore-db','postgres','CREATE DATABASE '+target)
  run(stage+'-restore-backup',['docker','exec',container,'pg_restore','-U','alpha_ci','-d',target,'--no-owner','--no-privileges','--exit-on-error','/tmp/'+stage+'.dump'])
  if stage=='baseline':
   assert snapshot(target,'baseline-restored')==before
   assert sql('baseline-restored-history',target,'SELECT COUNT(*) FROM "__EFMigrationsHistory"')=='7'
   (out/'baseline-restore-result.json').write_text(json.dumps({'restore':'PASS','businessRowsMatch':True,'migrations':7},indent=2))
  else: run('upgraded-restore-verification',['dotnet','run','--project',str(root/'candidate'),'--no-build','--no-restore','-c','Release','--',str(out),'restore'])
 sql('postgres-version','postgres','SELECT version()')
finally:
 run('cleanup',['docker','rm','-f',container])
