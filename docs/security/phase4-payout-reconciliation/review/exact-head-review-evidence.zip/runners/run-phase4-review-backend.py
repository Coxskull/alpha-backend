import pathlib,subprocess,os,time
src=pathlib.Path('/workspace/work/run-current-financial.py').read_text().replace('/workspace/work/current-financial-gate','/workspace/work/phase4-backend').replace('/workspace/work/current-financial-evidence','/workspace/work/phase4-review-backend-evidence')
src=src.replace("print(name,code,flush=True)\nrun('identity'", "print(name,code,flush=True)\n    if code: raise RuntimeError(name + ' failed')\nrun('identity'")
env=os.environ.copy()
for k in ('DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH'):env.pop(k,None)
env['DOCKER_HOST']='unix:///var/run/docker.sock'
container='alpha-phase4-reconciliation'
try:
 subprocess.run(['docker','run','-d','--name',container,'-p','127.0.0.1:5432:5432','-e','POSTGRES_USER=alpha_ci','-e','POSTGRES_PASSWORD=disposable-ci-only','-e','POSTGRES_DB=alpha_model_ci','postgres:16@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d'],env=env,check=True)
 for i in range(30):
  if subprocess.run(['docker','exec',container,'pg_isready','-U','alpha_ci'],env=env,stdout=subprocess.DEVNULL).returncode==0:break
  time.sleep(1)
 for db in ['alpha_migrations_ci','alpha_integration_ci']:subprocess.run(['docker','exec',container,'psql','-U','alpha_ci','-d','postgres','-c','CREATE DATABASE '+db],env=env,check=True)
 exec(compile(src,'phase1-runner','exec'))
finally:subprocess.run(['docker','rm','-f',container],env=env,check=True)
