import os,subprocess,pathlib,glob,json,time,urllib.request
root=pathlib.Path('/workspace/work/phase5-frontend/alpha-frontend');out=pathlib.Path('/workspace/work/phase5-frontend-evidence');env=os.environ.copy()
for k in list(env):
 if any(x in k.lower() for x in ['database','supabase','jwt','paypal','stripe','paymongo','connectionstrings','next_public']):del env[k]
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';env.update(PATH=str(pathlib.Path(node).parent)+':'+env['PATH'],NEXT_PUBLIC_API_URL='http://127.0.0.1:59999',NEXT_TELEMETRY_DISABLED='1',NPM_CONFIG_CACHE='/workspace/work/npm-cache')
out.mkdir(exist_ok=True)
out.mkdir(exist_ok=True)
results=[]
def run(name,args,allow_failure=False):
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 results.append({'check':name,'exitCode':r.returncode});(out/'execution.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
 if r.returncode and not allow_failure:raise RuntimeError(name)
run('clean-install',['npm','ci','--no-fund'])
run('exact-identity',['git','rev-parse','HEAD']);run('node-version',[node,'--version'])
run('typecheck-final',[node,'node_modules/typescript/bin/tsc','--noEmit'])
run('changed-lint-final',[node,'node_modules/eslint/bin/eslint.js','components/financials/PayoutReview.tsx','lib/payoutQuote.ts','tests/payoutQuote.test.ts','services/payouts.ts','services/financials.ts','app/mission-control/financials/page.tsx','app/mission-control/settlement-queue/page.tsx','app/mission-control/entrepreneur/page.tsx','app/mission-control/entrepreneur/payouts/page.tsx','app/mission-control/payout-reconciliation/page.tsx','services/reconciliation.ts','lib/reconciliation.ts','tests/reconciliation.test.ts','lib/payoutRecordInventory.ts','services/payoutRecordInventory.ts','tests/payoutRecordInventory.test.ts','app/mission-control/payout-record-inventory/page.tsx'])
run('contract-test-build',[node,'node_modules/typescript/bin/tsc','lib/payoutQuote.ts','tests/payoutQuote.test.ts','lib/reconciliation.ts','tests/reconciliation.test.ts','lib/payoutRecordInventory.ts','tests/payoutRecordInventory.test.ts','--outDir','/workspace/work/frontend-test-build','--module','commonjs','--moduleResolution','node','--target','es2020','--esModuleInterop','--skipLibCheck'])
run('contract-tests',[node,'--test','/workspace/work/frontend-test-build/tests/payoutQuote.test.js','/workspace/work/frontend-test-build/tests/reconciliation.test.js','/workspace/work/frontend-test-build/tests/payoutRecordInventory.test.js'])
run('production-audit',['npm','audit','--omit=dev','--json'],allow_failure=True)
run('build-node24',['npm','run','build'])
