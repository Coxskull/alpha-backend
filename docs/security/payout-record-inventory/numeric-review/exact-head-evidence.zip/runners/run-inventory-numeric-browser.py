import os,subprocess,pathlib,glob,json,time,urllib.request
root=pathlib.Path('/workspace/work/phase5-review-frontend/alpha-frontend');out=pathlib.Path('/workspace/work/phase5-review-frontend-evidence');env=os.environ.copy()
for k in list(env):
 if any(x in k.lower() for x in ['database','supabase','jwt','paypal','stripe','paymongo','connectionstrings','next_public']):del env[k]
node='/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node';env.update(PATH=str(pathlib.Path(node).parent)+':'+env['PATH'],NEXT_PUBLIC_API_URL='http://127.0.0.1:59999',NEXT_TELEMETRY_DISABLED='1',NPM_CONFIG_CACHE='/workspace/work/npm-cache')
log=(out/'server.log').open('w');server=subprocess.Popen([node,'node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port','5127'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
try:
 for i in range(60):
  try:urllib.request.urlopen('http://127.0.0.1:5127',timeout=1);break
  except Exception:time.sleep(0.5)
 with (out/'browser.log').open('w') as browserlog:
  result=subprocess.run([node,'/workspace/work/inventory-numeric-browser.cjs'],env=env,cwd=root,stdout=browserlog,stderr=subprocess.STDOUT,timeout=180)
  print('browser',result.returncode,flush=True)
  if result.returncode:raise RuntimeError('browser review failed')
finally:server.terminate();server.wait(timeout=20);log.close()
