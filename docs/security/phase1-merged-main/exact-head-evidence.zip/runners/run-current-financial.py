import os, subprocess, pathlib, json, time
root=pathlib.Path('/workspace/work/current-financial-gate'); out=pathlib.Path('/workspace/work/current-financial-evidence'); out.mkdir(exist_ok=True)
env=os.environ.copy()
for key in list(env):
    if any(s in key.lower() for s in ('paypal','paymongo','stripe','supabase','database','jwt','connectionstrings')): del env[key]
env.update(PATH='/workspace/.dotnet:/workspace/.tools:'+env['PATH'],DOTNET_ROOT='/workspace/.dotnet',DOTNET_CLI_HOME='/workspace/.dotnet-home',NUGET_PACKAGES='/workspace/.nuget/packages',DOTNET_CLI_TELEMETRY_OPTOUT='1')
results=[]
def run(name,args,timeout=600):
    start=time.time()
    with (out/(name+'.log')).open('w') as log:
        log.write('COMMAND '+json.dumps(args)+'\n'); log.flush()
        try: code=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=timeout).returncode
        except subprocess.TimeoutExpired: code=124
    results.append(dict(check=name,exitCode=code,seconds=round(time.time()-start,2)))
    (out/'execution.json').write_text(json.dumps(results,indent=2)); print(name,code,flush=True)
run('identity',['git','rev-parse','HEAD'])
run('dotnet-info',['dotnet','--info'])
for name,path in [('unit','Tests/Alpha.API.Tests/Alpha.API.Tests.csproj'),('integration','Tests/Alpha.API.Integration.Tests/Alpha.API.Integration.Tests.csproj'),('compatibility','Tests/Alpha.API.Compatibility/Alpha.API.Compatibility.csproj')]:
    run(name+'-restore',['dotnet','restore',path,'--locked-mode'])
    run(name+'-build',['dotnet','build',path,'-c','Release','--no-restore','-warnaserror'])
run('unit-coverage',['/workspace/.tools/coverlet',str(root/'Tests/Alpha.API.Tests/bin/Release/net8.0/Alpha.API.Tests.dll'),'--target','dotnet','--targetargs',f'test Tests/Alpha.API.Tests/Alpha.API.Tests.csproj -c Release --no-build --no-restore --logger trx;LogFileName=unit.trx --results-directory {out}','--include','[Alpha.API]*','--format','json','--format','cobertura','--output',str(out/'unit-coverage')])
for path in ['Alpha.API.csproj','Tests/Alpha.API.Tests/Alpha.API.Tests.csproj','Tests/Alpha.API.Integration.Tests/Alpha.API.Integration.Tests.csproj']:
    run('audit-'+pathlib.Path(path).stem,['dotnet','list',path,'package','--vulnerable','--include-transitive'])
run('database',['dotnet','run','--project','Tests/Alpha.API.Compatibility/Alpha.API.Compatibility.csproj','-c','Release','--no-build','--no-restore','--',str(out)])
run('integration-coverage',['/workspace/.tools/coverlet',str(root/'Tests/Alpha.API.Integration.Tests/bin/Release/net8.0/Alpha.API.Integration.Tests.dll'),'--target','dotnet','--targetargs',f'test Tests/Alpha.API.Integration.Tests/Alpha.API.Integration.Tests.csproj -c Release --no-build --no-restore --logger trx;LogFileName=integration.trx --results-directory {out}','--include','[Alpha.API]*','--merge-with',str(out/'unit-coverage.json'),'--format','cobertura','--output',str(out/'coverage.cobertura.xml')])
run('coverage-summary',['python3','scripts/coverage-summary.py',str(out/'coverage.cobertura.xml'),str(out/'coverage-summary.json')])
run('startup',['python3','scripts/startup-evidence.py','dotnet',str(out),'bin/Release/net8.0/Alpha.API.dll'])
