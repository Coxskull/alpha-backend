CREATE TABLE IF NOT EXISTS "__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL,
    CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId")
);

START TRANSACTION;

CREATE TABLE audit_logs (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    action text NOT NULL,
    performed_by text,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_audit_logs" PRIMARY KEY (id)
);

CREATE TABLE delivery_proof (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    image_url text NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_delivery_proof" PRIMARY KEY (id)
);

CREATE TABLE drivers (
    "Id" uuid NOT NULL,
    "FullName" text NOT NULL,
    "PhoneNumber" text,
    "VehicleType" text,
    "PlateNumber" text,
    "AvailabilityStatus" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "PK_drivers" PRIMARY KEY ("Id")
);

CREATE TABLE orders (
    id uuid NOT NULL,
    order_number text NOT NULL,
    customer_name text NOT NULL,
    pickup_address text NOT NULL,
    delivery_address text NOT NULL,
    item_description text NOT NULL,
    zone text NOT NULL,
    supplier_id uuid,
    driver_id uuid,
    status text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_orders" PRIMARY KEY (id)
);

CREATE TABLE status_history (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    status text NOT NULL,
    notes text,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_status_history" PRIMARY KEY (id)
);

CREATE TABLE suppliers (
    "Id" uuid NOT NULL,
    "Name" text NOT NULL,
    "ContactNumber" text,
    "Address" text,
    "AvailabilityStatus" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "PK_suppliers" PRIMARY KEY ("Id")
);

CREATE TABLE users (
    "Id" uuid NOT NULL,
    "FullName" text NOT NULL,
    "Email" text NOT NULL,
    "Phone" text,
    "Role" text NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "PK_users" PRIMARY KEY ("Id")
);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260609065938_InitialCreate', '8.0.0');

COMMIT;

START TRANSACTION;

CREATE INDEX "IX_orders_driver_id" ON orders (driver_id);

CREATE INDEX "IX_orders_supplier_id" ON orders (supplier_id);

ALTER TABLE orders ADD CONSTRAINT "FK_orders_drivers_driver_id" FOREIGN KEY (driver_id) REFERENCES drivers ("Id");

ALTER TABLE orders ADD CONSTRAINT "FK_orders_suppliers_supplier_id" FOREIGN KEY (supplier_id) REFERENCES suppliers ("Id");

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20260609152717_OrderRelations', '8.0.0');

COMMIT;

START TRANSACTION;

ALTER TABLE orders DROP CONSTRAINT "FK_orders_drivers_driver_id";

ALTER TABLE orders DROP CONSTRAINT "FK_orders_suppliers_supplier_id";

ALTER TABLE users ADD "IsActive" boolean NOT NULL DEFAULT FALSE;

ALTER TABLE users ADD "PasswordHash" text NOT NULL DEFAULT '';

ALTER TABLE users ADD referral_code text;

ALTER TABLE users ADD referral_joined_at timestamp with time zone;

ALTER TABLE users ADD referred_by_user_id uuid;

ALTER TABLE suppliers ADD "CurrentWorkload" integer NOT NULL DEFAULT 0;

ALTER TABLE suppliers ADD "ResponseRate" double precision NOT NULL DEFAULT 0.0;

ALTER TABLE suppliers ADD "Territory" text NOT NULL DEFAULT '';

ALTER TABLE suppliers ADD user_id uuid;

ALTER TABLE orders ADD country_code text NOT NULL DEFAULT '';

ALTER TABLE orders ADD currency text NOT NULL DEFAULT '';

ALTER TABLE orders ADD customer_id uuid;

ALTER TABLE drivers ADD "ActiveJobs" integer NOT NULL DEFAULT 0;

ALTER TABLE drivers ADD "LastSeenAt" timestamp with time zone;

ALTER TABLE drivers ADD "ResponseRate" double precision NOT NULL DEFAULT 0.0;

ALTER TABLE drivers ADD "Territory" text;

ALTER TABLE drivers ADD email text;

ALTER TABLE drivers ADD password_hash text;

ALTER TABLE drivers ADD user_id uuid;

CREATE TABLE auto_parts_commission_audit_logs (
    id uuid NOT NULL,
    policy_id uuid,
    policy_version integer,
    action text NOT NULL,
    performed_by_user_id uuid,
    before_snapshot text,
    after_snapshot text,
    reason text,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_auto_parts_commission_audit_logs" PRIMARY KEY (id),
    CONSTRAINT "FK_auto_parts_commission_audit_logs_users_performed_by_user_id" FOREIGN KEY (performed_by_user_id) REFERENCES users ("Id") ON DELETE SET NULL
);

CREATE TABLE auto_parts_commission_policies (
    id uuid NOT NULL,
    policy_name text NOT NULL,
    currency text NOT NULL,
    version integer NOT NULL,
    is_active boolean NOT NULL,
    notes text,
    effective_from timestamp with time zone NOT NULL,
    effective_to timestamp with time zone,
    created_by_user_id uuid,
    updated_by_user_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_auto_parts_commission_policies" PRIMARY KEY (id)
);

CREATE TABLE cart_items (
    id uuid NOT NULL,
    customer_id uuid NOT NULL,
    product_id uuid NOT NULL,
    quantity integer NOT NULL,
    CONSTRAINT "PK_cart_items" PRIMARY KEY (id)
);

CREATE TABLE customer_addresses (
    id uuid NOT NULL,
    customer_id uuid NOT NULL,
    address character varying(255) NOT NULL,
    city character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    zip_code character varying(20) NOT NULL,
    "Country" character varying(100) NOT NULL,
    CONSTRAINT "PK_customer_addresses" PRIMARY KEY (id)
);

CREATE TABLE customer_vehicles (
    id uuid NOT NULL,
    customer_id uuid NOT NULL,
    year integer NOT NULL,
    make character varying(100) NOT NULL,
    model character varying(100) NOT NULL,
    "Trim" character varying(100) NOT NULL,
    engine character varying(100) NOT NULL,
    "VIN" character varying(50) NOT NULL,
    nickname character varying(100) NOT NULL,
    CONSTRAINT "PK_customer_vehicles" PRIMARY KEY (id)
);

CREATE TABLE customers (
    id uuid NOT NULL,
    full_name character varying(150) NOT NULL,
    email character varying(150) NOT NULL,
    "PhoneNumber" character varying(30) NOT NULL,
    "PasswordHash" character varying(255) NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "PK_customers" PRIMARY KEY (id)
);

CREATE TABLE driver_payouts (
    id uuid NOT NULL,
    driver_id uuid NOT NULL,
    order_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text NOT NULL,
    payout_status text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    CONSTRAINT "PK_driver_payouts" PRIMARY KEY (id)
);

CREATE TABLE entrepreneur_earning_adjustments (
    id uuid NOT NULL,
    entrepreneur_earning_id uuid NOT NULL,
    adjustment_type character varying(50) NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(10) NOT NULL,
    reason character varying(500) NOT NULL,
    related_payment_id uuid,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_entrepreneur_earning_adjustments" PRIMARY KEY (id)
);

CREATE TABLE entrepreneur_market_configurations (
    id uuid NOT NULL,
    country_code character varying(10) NOT NULL,
    currency character varying(10) NOT NULL,
    commission_rate numeric(10,6) NOT NULL,
    minimum_payout_threshold numeric(18,2) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_entrepreneur_market_configurations" PRIMARY KEY (id)
);

CREATE TABLE entrepreneur_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    city text NOT NULL,
    state text,
    country text NOT NULL,
    preferred_language text NOT NULL,
    business_name text,
    entrepreneurial_goal text,
    onboarding_status text NOT NULL,
    terms_accepted_at timestamp with time zone,
    rewards_policy_accepted_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_entrepreneur_profiles" PRIMARY KEY (id)
);

CREATE TABLE entrepreneur_program_configurations (
    id uuid NOT NULL,
    program_enabled boolean NOT NULL,
    default_commission_rate numeric NOT NULL,
    minimum_payout_threshold numeric NOT NULL,
    payout_frequency text NOT NULL,
    qualifying_provider_roles text NOT NULL,
    qualifying_transaction_types text NOT NULL,
    holding_period_days integer NOT NULL,
    program_start_date timestamp with time zone,
    program_end_date timestamp with time zone,
    maximum_referral_level integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by_user_id uuid,
    CONSTRAINT "PK_entrepreneur_program_configurations" PRIMARY KEY (id)
);

CREATE TABLE entrepreneur_referrals (
    id uuid NOT NULL,
    entrepreneur_user_id uuid NOT NULL,
    recruited_user_id uuid NOT NULL,
    referral_code text NOT NULL,
    referral_date timestamp with time zone NOT NULL,
    provider_activation_date timestamp with time zone,
    referral_status text NOT NULL,
    eligibility_status text NOT NULL,
    is_direct_referral boolean NOT NULL,
    ended_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    entrepreneur_eligibility_status text NOT NULL,
    CONSTRAINT "PK_entrepreneur_referrals" PRIMARY KEY (id),
    CONSTRAINT "FK_entrepreneur_referrals_users_entrepreneur_user_id" FOREIGN KEY (entrepreneur_user_id) REFERENCES users ("Id") ON DELETE RESTRICT,
    CONSTRAINT "FK_entrepreneur_referrals_users_recruited_user_id" FOREIGN KEY (recruited_user_id) REFERENCES users ("Id") ON DELETE RESTRICT
);

CREATE TABLE entrepreneur_roles (
    id uuid NOT NULL,
    role_key text NOT NULL,
    display_name text NOT NULL,
    description text,
    icon text,
    is_operational_role boolean NOT NULL,
    is_active boolean NOT NULL,
    sort_order integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_entrepreneur_roles" PRIMARY KEY (id),
    CONSTRAINT "AK_entrepreneur_roles_role_key" UNIQUE (role_key)
);

CREATE TABLE entrepreneur_transaction_costs (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    payment_id uuid,
    cost_type character varying(100) NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(10) NOT NULL,
    description character varying(500),
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_entrepreneur_transaction_costs" PRIMARY KEY (id)
);

CREATE TABLE "EntrepreneurPayoutBatches" (
    "Id" uuid NOT NULL,
    "SettlementDate" timestamp with time zone NOT NULL,
    "Currency" text NOT NULL,
    "TotalAmount" numeric NOT NULL,
    "EarningCount" integer NOT NULL,
    "Status" text NOT NULL,
    "PayoutReference" text,
    "CreatedAt" timestamp with time zone NOT NULL,
    "PaidAt" timestamp with time zone,
    "ProcessedByUserId" uuid,
    CONSTRAINT "PK_EntrepreneurPayoutBatches" PRIMARY KEY ("Id")
);

CREATE TABLE "EntrepreneurReferralAudits" (
    "Id" uuid NOT NULL,
    "EntrepreneurReferralId" uuid NOT NULL,
    "OldEntrepreneurUserId" uuid,
    "NewEntrepreneurUserId" uuid,
    "Reason" text NOT NULL,
    "ChangedByUserId" uuid NOT NULL,
    "ChangedAt" timestamp with time zone NOT NULL,
    CONSTRAINT "PK_EntrepreneurReferralAudits" PRIMARY KEY ("Id")
);

CREATE TABLE invoices (
    id uuid NOT NULL,
    order_id uuid,
    invoice_number text NOT NULL,
    subtotal numeric NOT NULL,
    tax numeric NOT NULL,
    total numeric NOT NULL,
    currency text NOT NULL,
    issued_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_invoices" PRIMARY KEY (id)
);

CREATE TABLE mechanics (
    id uuid NOT NULL,
    user_id uuid,
    full_name text NOT NULL,
    email text,
    phone text,
    service_area text,
    availability_status text NOT NULL,
    latitude numeric,
    longitude numeric,
    service_radius_km numeric NOT NULL,
    active_jobs integer NOT NULL,
    response_rate numeric NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_mechanics" PRIMARY KEY (id)
);

CREATE TABLE operational_alerts (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    alert_type text NOT NULL,
    message text NOT NULL,
    resolved boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_operational_alerts" PRIMARY KEY (id)
);

CREATE TABLE order_financials (
    id uuid NOT NULL,
    order_id uuid,
    service_request_id uuid,
    currency text NOT NULL,
    exchange_rate numeric NOT NULL,
    item_subtotal numeric NOT NULL,
    delivery_fee numeric NOT NULL,
    service_fee numeric NOT NULL,
    tax numeric NOT NULL,
    discount numeric NOT NULL,
    total_amount numeric NOT NULL,
    customer_paid numeric NOT NULL,
    supplier_amount numeric NOT NULL,
    driver_amount numeric NOT NULL,
    mechanic_amount numeric NOT NULL,
    alpha_platform_fee numeric NOT NULL,
    supplier_earning numeric NOT NULL,
    driver_earning numeric NOT NULL,
    company_revenue numeric NOT NULL,
    financial_status text NOT NULL,
    payout_status text NOT NULL,
    completion_proof_url text,
    created_at timestamp with time zone NOT NULL,
    settlement_status text NOT NULL,
    tax_collected numeric NOT NULL,
    tax_withheld numeric NOT NULL,
    processing_fee numeric NOT NULL,
    refund_amount numeric(18,2) NOT NULL,
    dispute_reserve numeric NOT NULL,
    supplier_net_payable numeric NOT NULL,
    driver_net_payable numeric NOT NULL,
    mechanic_net_payable numeric NOT NULL,
    alpha_net_revenue numeric NOT NULL,
    reconciliation_difference numeric NOT NULL,
    auto_parts_commission numeric(18,2) NOT NULL,
    auto_parts_commission_rate numeric(10,6) NOT NULL,
    auto_parts_commission_policy_id uuid,
    auto_parts_commission_policy_version integer,
    parts_supplier_gross numeric(18,2) NOT NULL,
    parts_supplier_net numeric(18,2) NOT NULL,
    alpha_gross_parts_commission numeric(18,2) NOT NULL,
    alpha_gross_mechanic_commission numeric(18,2) NOT NULL,
    alpha_gross_delivery_commission numeric(18,2) NOT NULL,
    alpha_gross_platform_commission numeric(18,2) NOT NULL,
    direct_transaction_costs numeric(18,2) NOT NULL,
    alpha_eligible_net_platform_revenue numeric(18,2) NOT NULL,
    entrepreneur_commission numeric(18,2) NOT NULL,
    alpha_retained_revenue numeric(18,2) NOT NULL,
    chargeback_amount numeric(18,2) NOT NULL,
    chargeback_fee numeric(18,2) NOT NULL,
    payment_status text NOT NULL,
    provider_payout_status text NOT NULL,
    entrepreneur_payout_status text NOT NULL,
    CONSTRAINT "PK_order_financials" PRIMARY KEY (id)
);

CREATE TABLE parts_requests (
    id uuid NOT NULL,
    service_request_id uuid NOT NULL,
    mechanic_id uuid,
    part_description text NOT NULL,
    notes text,
    status text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    CONSTRAINT "PK_parts_requests" PRIMARY KEY (id)
);

CREATE TABLE password_reset_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_password_reset_tokens" PRIMARY KEY (id),
    CONSTRAINT "FK_password_reset_tokens_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

CREATE TABLE payment_webhook_events (
    id uuid NOT NULL,
    gateway text NOT NULL,
    gateway_event_id text NOT NULL,
    event_type text NOT NULL,
    payload jsonb NOT NULL,
    processed boolean NOT NULL,
    processing_error text,
    received_at timestamp with time zone NOT NULL,
    processing_until timestamp with time zone,
    processed_at timestamp with time zone,
    CONSTRAINT "PK_payment_webhook_events" PRIMARY KEY (id)
);

CREATE TABLE payments (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text NOT NULL,
    payment_method text NOT NULL,
    payment_status text NOT NULL,
    transaction_reference text,
    payment_gateway text,
    gateway_checkout_session_id text,
    gateway_payment_id text,
    checkout_url text,
    failure_reason text,
    gateway_fee numeric NOT NULL,
    gateway_response jsonb,
    expires_at timestamp with time zone,
    paid_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    refunded_amount numeric NOT NULL,
    refund_status text NOT NULL,
    refund_reference text,
    refunded_at timestamp with time zone,
    CONSTRAINT "PK_payments" PRIMARY KEY (id)
);

CREATE TABLE products (
    id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    part_number text NOT NULL,
    brand text NOT NULL,
    name text NOT NULL,
    description text NOT NULL,
    image_url text NOT NULL,
    price numeric NOT NULL,
    quantity_available integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone,
    low_stock_threshold integer NOT NULL,
    image_base64 text,
    currency text NOT NULL,
    country_code text NOT NULL,
    CONSTRAINT "PK_products" PRIMARY KEY (id)
);

CREATE TABLE referral_commission_rates (
    id uuid NOT NULL,
    transaction_type text NOT NULL,
    source_role text NOT NULL,
    rate numeric(10,6) NOT NULL,
    fixed_amount numeric(18,2),
    currency text NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_referral_commission_rates" PRIMARY KEY (id)
);

CREATE TABLE referral_settings (
    id uuid NOT NULL,
    setting_key text NOT NULL,
    setting_value text NOT NULL,
    description text,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_referral_settings" PRIMARY KEY (id)
);

CREATE TABLE referral_transactions (
    id uuid NOT NULL,
    beneficiary_user_id uuid NOT NULL,
    source_user_id uuid NOT NULL,
    order_id uuid,
    service_request_id uuid,
    payment_id uuid,
    transaction_type text NOT NULL,
    source_role text,
    source_description text,
    gross_amount numeric(18,2) NOT NULL,
    commission_rate numeric(10,6) NOT NULL,
    commission_amount numeric(18,2) NOT NULL,
    currency text NOT NULL,
    referral_level integer NOT NULL,
    status text NOT NULL,
    available_at timestamp with time zone,
    paid_at timestamp with time zone,
    metadata jsonb,
    created_at timestamp with time zone NOT NULL,
    event_key text,
    description text,
    eligible_amount numeric(18,2) NOT NULL,
    approved_at timestamp with time zone,
    CONSTRAINT "PK_referral_transactions" PRIMARY KEY (id),
    CONSTRAINT "FK_referral_transactions_users_beneficiary_user_id" FOREIGN KEY (beneficiary_user_id) REFERENCES users ("Id") ON DELETE RESTRICT,
    CONSTRAINT "FK_referral_transactions_users_source_user_id" FOREIGN KEY (source_user_id) REFERENCES users ("Id") ON DELETE RESTRICT
);

CREATE TABLE repair_proofs (
    id uuid NOT NULL,
    service_request_id uuid NOT NULL,
    mechanic_id uuid,
    image_url text NOT NULL,
    notes text,
    uploaded_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_repair_proofs" PRIMARY KEY (id)
);

CREATE TABLE role_verification_applications (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_key text NOT NULL,
    status text NOT NULL,
    legal_name text,
    business_name text,
    identification_number text,
    license_number text,
    vehicle_plate_number text,
    years_of_experience integer,
    business_address text,
    applicant_notes text,
    reviewer_notes text,
    rejection_reason text,
    submitted_at timestamp with time zone,
    reviewed_at timestamp with time zone,
    reviewed_by_user_id uuid,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_role_verification_applications" PRIMARY KEY (id),
    CONSTRAINT "FK_role_verification_applications_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

CREATE TABLE security_logs (
    id uuid NOT NULL,
    user_id uuid,
    email text,
    role text,
    path text NOT NULL,
    method text NOT NULL,
    status_code integer NOT NULL,
    message text,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_security_logs" PRIMARY KEY (id)
);

CREATE TABLE settlement_queue (
    id uuid NOT NULL,
    order_financial_id uuid NOT NULL,
    payee_type text NOT NULL,
    payee_id uuid,
    amount numeric(18,2) NOT NULL,
    status text NOT NULL,
    reviewed_by text,
    reviewed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_settlement_queue" PRIMARY KEY (id)
);

CREATE TABLE supplier_payouts (
    id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    order_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text NOT NULL,
    payout_status text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    paid_at timestamp with time zone,
    CONSTRAINT "PK_supplier_payouts" PRIMARY KEY (id)
);

CREATE TABLE tax_calculations (
    id uuid NOT NULL,
    order_id uuid,
    payment_id uuid,
    country text NOT NULL,
    region text,
    currency text NOT NULL,
    component text NOT NULL,
    tax_type text NOT NULL,
    tax_rate numeric NOT NULL,
    taxable_base numeric NOT NULL,
    tax_amount numeric NOT NULL,
    revenue_recipient text NOT NULL,
    tax_responsible_party text NOT NULL,
    withholding_required boolean NOT NULL,
    withholding_amount numeric NOT NULL,
    tax_rule_id uuid NOT NULL,
    tax_rule_version integer NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_tax_calculations" PRIMARY KEY (id)
);

CREATE TABLE tax_ledger_entries (
    id uuid NOT NULL,
    order_id uuid,
    payment_id uuid,
    settlement_id uuid,
    provider_id uuid,
    entry_type text NOT NULL DEFAULT 'calculation',
    tax_type text NOT NULL,
    component text NOT NULL,
    tax_rate numeric NOT NULL,
    taxable_base numeric NOT NULL,
    tax_collected numeric NOT NULL,
    tax_withheld numeric NOT NULL,
    tax_refunded numeric NOT NULL,
    responsible_party text NOT NULL,
    tax_rule_version integer NOT NULL,
    actor text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_tax_ledger_entries" PRIMARY KEY (id)
);

CREATE TABLE tax_rules (
    id uuid NOT NULL,
    country text NOT NULL,
    region text,
    tax_type text NOT NULL,
    tax_rate numeric NOT NULL,
    component text NOT NULL,
    responsible_party text NOT NULL,
    is_tax_inclusive boolean NOT NULL,
    withholding_required boolean NOT NULL,
    withholding_rate numeric NOT NULL,
    effective_from timestamp with time zone NOT NULL,
    expires_at timestamp with time zone,
    enabled boolean NOT NULL,
    version integer NOT NULL,
    CONSTRAINT "PK_tax_rules" PRIMARY KEY (id)
);

CREATE TABLE auto_parts_commission_calculations (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    order_financial_id uuid,
    policy_id uuid NOT NULL,
    policy_version integer NOT NULL,
    currency text NOT NULL,
    parts_subtotal numeric NOT NULL,
    total_commission numeric NOT NULL,
    effective_commission_rate numeric NOT NULL,
    calculated_at timestamp with time zone NOT NULL,
    created_by text NOT NULL,
    CONSTRAINT "PK_auto_parts_commission_calculations" PRIMARY KEY (id),
    CONSTRAINT "FK_auto_parts_commission_calculations_auto_parts_commission_po~" FOREIGN KEY (policy_id) REFERENCES auto_parts_commission_policies (id) ON DELETE RESTRICT
);

CREATE TABLE auto_parts_commission_tiers (
    id uuid NOT NULL,
    policy_id uuid NOT NULL,
    tier_order integer NOT NULL,
    minimum_amount numeric(18,2) NOT NULL,
    maximum_amount numeric(18,2),
    commission_percentage numeric(5,2) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_auto_parts_commission_tiers" PRIMARY KEY (id),
    CONSTRAINT "FK_auto_parts_commission_tiers_auto_parts_commission_policies_~" FOREIGN KEY (policy_id) REFERENCES auto_parts_commission_policies (id) ON DELETE CASCADE
);

CREATE TABLE user_roles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    role_key text NOT NULL,
    status text NOT NULL,
    is_primary boolean NOT NULL,
    activated_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_user_roles" PRIMARY KEY (id),
    CONSTRAINT "FK_user_roles_entrepreneur_roles_role_key" FOREIGN KEY (role_key) REFERENCES entrepreneur_roles (role_key) ON DELETE CASCADE,
    CONSTRAINT "FK_user_roles_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

CREATE TABLE service_requests (
    id uuid NOT NULL,
    customer_id uuid,
    customer_name text NOT NULL,
    customer_phone text,
    vehicle_info text,
    issue_description text NOT NULL,
    service_address text NOT NULL,
    zone text NOT NULL,
    latitude numeric,
    longitude numeric,
    provider_id uuid,
    mechanic_id uuid,
    driver_id uuid,
    parts_request_id uuid,
    status text NOT NULL,
    parts_request_note text,
    proof_image_url text,
    rejection_reason text,
    final_amount numeric NOT NULL,
    payment_status text NOT NULL,
    provider_accepted_at timestamp with time zone,
    mechanic_accepted_at timestamp with time zone,
    driver_assigned_at timestamp with time zone,
    accepted_at timestamp with time zone,
    started_at timestamp with time zone,
    proof_uploaded_at timestamp with time zone,
    completed_at timestamp with time zone,
    closed_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_service_requests" PRIMARY KEY (id),
    CONSTRAINT "FK_service_requests_drivers_driver_id" FOREIGN KEY (driver_id) REFERENCES drivers ("Id") ON DELETE SET NULL,
    CONSTRAINT "FK_service_requests_mechanics_mechanic_id" FOREIGN KEY (mechanic_id) REFERENCES mechanics (id) ON DELETE SET NULL,
    CONSTRAINT "FK_service_requests_suppliers_provider_id" FOREIGN KEY (provider_id) REFERENCES suppliers ("Id") ON DELETE SET NULL
);

CREATE TABLE entrepreneur_earnings (
    id uuid NOT NULL,
    entrepreneur_user_id uuid NOT NULL,
    recruiter_id uuid NOT NULL,
    recruited_provider_id uuid NOT NULL,
    provider_role text NOT NULL,
    order_id uuid NOT NULL,
    transaction_id text NOT NULL,
    payment_id uuid,
    transaction_date timestamp with time zone NOT NULL,
    alpha_gross_platform_commission numeric NOT NULL,
    direct_transaction_costs numeric NOT NULL,
    eligible_net_platform_revenue numeric NOT NULL,
    entrepreneur_percentage numeric NOT NULL,
    entrepreneur_earnings_amount numeric NOT NULL,
    currency text NOT NULL,
    earning_status text NOT NULL,
    refund_adjustment numeric NOT NULL,
    chargeback_adjustment numeric NOT NULL,
    payout_batch_id uuid,
    payout_date timestamp with time zone,
    payout_reference text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    event_key text,
    CONSTRAINT "PK_entrepreneur_earnings" PRIMARY KEY (id),
    CONSTRAINT "FK_entrepreneur_earnings_orders_order_id" FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE RESTRICT,
    CONSTRAINT "FK_entrepreneur_earnings_payments_payment_id" FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE SET NULL,
    CONSTRAINT "FK_entrepreneur_earnings_users_entrepreneur_user_id" FOREIGN KEY (entrepreneur_user_id) REFERENCES users ("Id") ON DELETE RESTRICT
);

CREATE TABLE payment_operations (
    id uuid NOT NULL,
    payment_id uuid NOT NULL,
    kind character varying(16) NOT NULL,
    idempotency_key character varying(128) NOT NULL,
    amount numeric(18,2) NOT NULL,
    currency character varying(3) NOT NULL,
    state character varying(16) NOT NULL,
    provider_request_id character varying(38) NOT NULL,
    provider_reference character varying(128),
    provider_parent_reference character varying(128) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_payment_operations" PRIMARY KEY (id),
    CONSTRAINT "FK_payment_operations_payments_payment_id" FOREIGN KEY (payment_id) REFERENCES payments (id) ON DELETE RESTRICT
);

CREATE TABLE order_items (
    id uuid NOT NULL,
    order_id uuid NOT NULL,
    product_id uuid NOT NULL,
    supplier_id uuid NOT NULL,
    quantity integer NOT NULL,
    unit_price numeric,
    CONSTRAINT "PK_order_items" PRIMARY KEY (id),
    CONSTRAINT "FK_order_items_orders_order_id" FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE,
    CONSTRAINT "FK_order_items_products_product_id" FOREIGN KEY (product_id) REFERENCES products (id) ON DELETE RESTRICT,
    CONSTRAINT "FK_order_items_suppliers_supplier_id" FOREIGN KEY (supplier_id) REFERENCES suppliers ("Id") ON DELETE RESTRICT
);

CREATE TABLE role_verification_documents (
    id uuid NOT NULL,
    application_id uuid NOT NULL,
    document_type text NOT NULL,
    original_file_name text NOT NULL,
    storage_path text NOT NULL,
    file_path text,
    content_type text,
    file_size_bytes bigint,
    verification_status text NOT NULL DEFAULT 'pending',
    reviewer_notes text,
    uploaded_at timestamp with time zone NOT NULL,
    reviewed_at timestamp with time zone,
    reviewed_by_user_id uuid,
    CONSTRAINT "PK_role_verification_documents" PRIMARY KEY (id),
    CONSTRAINT "FK_role_verification_documents_role_verification_applications_~" FOREIGN KEY (application_id) REFERENCES role_verification_applications (id) ON DELETE CASCADE
);

CREATE TABLE auto_parts_commission_calculation_lines (
    id uuid NOT NULL,
    calculation_id uuid NOT NULL,
    tier_id uuid NOT NULL,
    tier_order integer NOT NULL,
    tier_minimum numeric NOT NULL,
    tier_maximum numeric,
    tier_percentage numeric NOT NULL,
    amount_in_tier numeric NOT NULL,
    commission_amount numeric NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_auto_parts_commission_calculation_lines" PRIMARY KEY (id),
    CONSTRAINT "FK_auto_parts_commission_calculation_lines_auto_parts_commissi~" FOREIGN KEY (calculation_id) REFERENCES auto_parts_commission_calculations (id) ON DELETE CASCADE,
    CONSTRAINT "FK_auto_parts_commission_calculation_lines_auto_parts_commiss~1" FOREIGN KEY (tier_id) REFERENCES auto_parts_commission_tiers (id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX "IX_users_referral_code" ON users (referral_code);

CREATE INDEX "IX_users_referred_by_user_id" ON users (referred_by_user_id);

CREATE INDEX "IX_orders_customer_id" ON orders (customer_id);

CREATE INDEX "IX_drivers_user_id" ON drivers (user_id);

CREATE UNIQUE INDEX "IX_delivery_proof_order_id" ON delivery_proof (order_id);

CREATE INDEX "IX_auto_parts_commission_audit_logs_performed_by_user_id" ON auto_parts_commission_audit_logs (performed_by_user_id);

CREATE INDEX "IX_auto_parts_commission_calculation_lines_calculation_id" ON auto_parts_commission_calculation_lines (calculation_id);

CREATE INDEX "IX_auto_parts_commission_calculation_lines_tier_id" ON auto_parts_commission_calculation_lines (tier_id);

CREATE INDEX "IX_auto_parts_commission_calculations_policy_id" ON auto_parts_commission_calculations (policy_id);

CREATE INDEX "IX_auto_parts_commission_tiers_policy_id_tier_order" ON auto_parts_commission_tiers (policy_id, tier_order);

CREATE INDEX "IX_entrepreneur_earning_adjustments_entrepreneur_earning_id" ON entrepreneur_earning_adjustments (entrepreneur_earning_id);

CREATE INDEX "IX_entrepreneur_earnings_entrepreneur_user_id" ON entrepreneur_earnings (entrepreneur_user_id);

CREATE INDEX "IX_entrepreneur_earnings_order_id" ON entrepreneur_earnings (order_id);

CREATE INDEX "IX_entrepreneur_earnings_payment_id" ON entrepreneur_earnings (payment_id);

CREATE UNIQUE INDEX "IX_entrepreneur_market_configurations_country_code_currency" ON entrepreneur_market_configurations (country_code, currency);

CREATE UNIQUE INDEX "IX_entrepreneur_profiles_user_id" ON entrepreneur_profiles (user_id);

CREATE INDEX "IX_entrepreneur_referrals_entrepreneur_user_id" ON entrepreneur_referrals (entrepreneur_user_id);

CREATE INDEX "IX_entrepreneur_referrals_recruited_user_id" ON entrepreneur_referrals (recruited_user_id);

CREATE INDEX "IX_entrepreneur_transaction_costs_order_id" ON entrepreneur_transaction_costs (order_id);

CREATE INDEX "IX_order_items_order_id" ON order_items (order_id);

CREATE INDEX "IX_order_items_product_id" ON order_items (product_id);

CREATE INDEX "IX_order_items_supplier_id" ON order_items (supplier_id);

CREATE UNIQUE INDEX "IX_password_reset_tokens_token_hash" ON password_reset_tokens (token_hash);

CREATE INDEX "IX_password_reset_tokens_user_id" ON password_reset_tokens (user_id);

CREATE UNIQUE INDEX "IX_payment_operations_kind_provider_reference" ON payment_operations (kind, provider_reference) WHERE provider_reference IS NOT NULL;

CREATE UNIQUE INDEX "IX_payment_operations_payment_id_kind_idempotency_key" ON payment_operations (payment_id, kind, idempotency_key);

CREATE UNIQUE INDEX "IX_payment_operations_provider_request_id" ON payment_operations (provider_request_id);

CREATE UNIQUE INDEX "IX_payment_webhook_events_gateway_gateway_event_id" ON payment_webhook_events (gateway, gateway_event_id);

CREATE INDEX "IX_referral_commission_rates_transaction_type_source_role_curr~" ON referral_commission_rates (transaction_type, source_role, currency);

CREATE UNIQUE INDEX "IX_referral_settings_setting_key" ON referral_settings (setting_key);

CREATE INDEX "IX_referral_transactions_beneficiary_user_id" ON referral_transactions (beneficiary_user_id);

CREATE UNIQUE INDEX "IX_referral_transactions_event_key" ON referral_transactions (event_key);

CREATE INDEX "IX_referral_transactions_order_id" ON referral_transactions (order_id);

CREATE INDEX "IX_referral_transactions_source_user_id" ON referral_transactions (source_user_id);

CREATE UNIQUE INDEX "IX_role_verification_applications_user_id_role_key" ON role_verification_applications (user_id, role_key);

CREATE INDEX "IX_role_verification_documents_application_id" ON role_verification_documents (application_id);

CREATE INDEX "IX_service_requests_driver_id" ON service_requests (driver_id);

CREATE INDEX "IX_service_requests_mechanic_id" ON service_requests (mechanic_id);

CREATE INDEX "IX_service_requests_provider_id" ON service_requests (provider_id);

CREATE UNIQUE INDEX "IX_tax_calculations_order_id_component_tax_type" ON tax_calculations (order_id, component, tax_type);

CREATE INDEX "IX_user_roles_role_key" ON user_roles (role_key);

CREATE UNIQUE INDEX "IX_user_roles_user_id_role_key" ON user_roles (user_id, role_key);

ALTER TABLE delivery_proof ADD CONSTRAINT "FK_delivery_proof_orders_order_id" FOREIGN KEY (order_id) REFERENCES orders (id) ON DELETE CASCADE;

ALTER TABLE drivers ADD CONSTRAINT "FK_drivers_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE SET NULL;

ALTER TABLE orders ADD CONSTRAINT "FK_orders_drivers_driver_id" FOREIGN KEY (driver_id) REFERENCES drivers ("Id") ON DELETE RESTRICT;

ALTER TABLE orders ADD CONSTRAINT "FK_orders_suppliers_supplier_id" FOREIGN KEY (supplier_id) REFERENCES suppliers ("Id") ON DELETE RESTRICT;

ALTER TABLE orders ADD CONSTRAINT "FK_orders_users_customer_id" FOREIGN KEY (customer_id) REFERENCES users ("Id") ON DELETE SET NULL;

ALTER TABLE users ADD CONSTRAINT "FK_users_users_referred_by_user_id" FOREIGN KEY (referred_by_user_id) REFERENCES users ("Id") ON DELETE SET NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012030904_ReproduceModelAndPaymentOperations', '8.0.0');

COMMIT;

START TRANSACTION;

ALTER TABLE payments ALTER COLUMN order_id DROP NOT NULL;

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012032142_AlignLegacyPaymentAssociation', '8.0.0');

COMMIT;

START TRANSACTION;

CREATE TABLE community_builder_cities (
    id uuid NOT NULL,
    builder_user_id uuid NOT NULL,
    city text NOT NULL,
    state text,
    country text NOT NULL,
    member_count integer NOT NULL,
    active_member_count integer NOT NULL,
    completed_transaction_count integer NOT NULL,
    connected_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_community_builder_cities" PRIMARY KEY (id),
    CONSTRAINT "FK_community_builder_cities_users_builder_user_id" FOREIGN KEY (builder_user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

CREATE TABLE community_builder_profiles (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    home_city text NOT NULL,
    home_state text,
    country text NOT NULL,
    builder_status text NOT NULL,
    total_cities_connected integer NOT NULL,
    approved_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_community_builder_profiles" PRIMARY KEY (id),
    CONSTRAINT "FK_community_builder_profiles_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

CREATE TABLE member_business_activity (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    completed_orders integer NOT NULL,
    completed_service_requests integer NOT NULL,
    completed_deliveries integer NOT NULL,
    fulfilled_parts_orders integer NOT NULL,
    customer_purchases integer NOT NULL,
    gross_transaction_value numeric(18,2) NOT NULL,
    first_business_activity_at timestamp with time zone,
    last_business_activity_at timestamp with time zone,
    is_business_active boolean NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_member_business_activity" PRIMARY KEY (id),
    CONSTRAINT "FK_member_business_activity_users_user_id" FOREIGN KEY (user_id) REFERENCES users ("Id") ON DELETE CASCADE
);

INSERT INTO entrepreneur_roles (id, created_at, description, display_name, icon, is_active, is_operational_role, role_key, sort_order)
VALUES ('00000000-0000-0000-0000-000000000001', TIMESTAMPTZ '2026-10-12T00:00:00Z', NULL, 'Vehicle Owner', NULL, TRUE, FALSE, 'customer', 1);
INSERT INTO entrepreneur_roles (id, created_at, description, display_name, icon, is_active, is_operational_role, role_key, sort_order)
VALUES ('00000000-0000-0000-0000-000000000002', TIMESTAMPTZ '2026-10-12T00:00:00Z', NULL, 'Motorcycle Rider', NULL, TRUE, TRUE, 'driver', 2);
INSERT INTO entrepreneur_roles (id, created_at, description, display_name, icon, is_active, is_operational_role, role_key, sort_order)
VALUES ('00000000-0000-0000-0000-000000000003', TIMESTAMPTZ '2026-10-12T00:00:00Z', NULL, 'Mechanic', NULL, TRUE, TRUE, 'mechanic', 3);
INSERT INTO entrepreneur_roles (id, created_at, description, display_name, icon, is_active, is_operational_role, role_key, sort_order)
VALUES ('00000000-0000-0000-0000-000000000004', TIMESTAMPTZ '2026-10-12T00:00:00Z', NULL, 'Auto Parts Store', NULL, TRUE, TRUE, 'supplier', 4);
INSERT INTO entrepreneur_roles (id, created_at, description, display_name, icon, is_active, is_operational_role, role_key, sort_order)
VALUES ('00000000-0000-0000-0000-000000000005', TIMESTAMPTZ '2026-10-12T00:00:00Z', NULL, 'Community Builder', NULL, TRUE, FALSE, 'community_builder', 5);

CREATE UNIQUE INDEX "IX_community_builder_cities_builder_user_id_city_state_country" ON community_builder_cities (builder_user_id, city, state, country) NULLS NOT DISTINCT;

CREATE UNIQUE INDEX "IX_community_builder_profiles_user_id" ON community_builder_profiles (user_id);

CREATE UNIQUE INDEX "IX_member_business_activity_user_id" ON member_business_activity (user_id);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012065015_CompleteRegistrationSchema', '8.0.0');

COMMIT;

START TRANSACTION;

ALTER TABLE settlement_queue ADD recovery_offset numeric(18,2) NOT NULL DEFAULT 0.0;

ALTER TABLE settlement_queue ADD refund_adjustment numeric(18,2) NOT NULL DEFAULT 0.0;

ALTER TABLE payment_operations ADD allocation_fingerprint character varying(64);

CREATE TABLE refund_allocations (
    id uuid NOT NULL,
    operation_id uuid NOT NULL,
    source_kind character varying(16) NOT NULL,
    source_id uuid NOT NULL,
    payee_type character varying(16) NOT NULL,
    payee_id uuid NOT NULL,
    currency character varying(3) NOT NULL,
    amount numeric(18,2) NOT NULL,
    future_recovery boolean NOT NULL,
    recovered_amount numeric(18,2) NOT NULL,
    reviewed_by uuid NOT NULL,
    evidence character varying(1000) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_refund_allocations" PRIMARY KEY (id),
    CONSTRAINT "FK_refund_allocations_payment_operations_operation_id" FOREIGN KEY (operation_id) REFERENCES payment_operations (id) ON DELETE RESTRICT
);

CREATE TABLE payout_recovery_offsets (
    id uuid NOT NULL,
    allocation_id uuid NOT NULL,
    target_kind character varying(16) NOT NULL,
    target_id uuid NOT NULL,
    amount numeric(18,2) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    CONSTRAINT "PK_payout_recovery_offsets" PRIMARY KEY (id),
    CONSTRAINT "FK_payout_recovery_offsets_refund_allocations_allocation_id" FOREIGN KEY (allocation_id) REFERENCES refund_allocations (id) ON DELETE RESTRICT
);

CREATE UNIQUE INDEX "IX_payout_recovery_offsets_allocation_id_target_kind_target_id" ON payout_recovery_offsets (allocation_id, target_kind, target_id);

CREATE UNIQUE INDEX "IX_refund_allocations_operation_id_source_kind_source_id" ON refund_allocations (operation_id, source_kind, source_id);

CREATE INDEX "IX_refund_allocations_payee_type_payee_id_currency" ON refund_allocations (payee_type, payee_id, currency);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012071522_AttributedRefundRecovery', '8.0.0');

COMMIT;

START TRANSACTION;

CREATE FUNCTION reject_financial_history_change() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Financial history is append-only' USING ERRCODE = '23514';
END $$;
CREATE TRIGGER audit_logs_append_only BEFORE UPDATE OR DELETE ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION reject_financial_history_change();
CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs
    FOR EACH STATEMENT EXECUTE FUNCTION reject_financial_history_change();
CREATE TRIGGER recovery_offsets_append_only BEFORE UPDATE OR DELETE ON payout_recovery_offsets
    FOR EACH ROW EXECUTE FUNCTION reject_financial_history_change();
CREATE TRIGGER recovery_offsets_no_truncate BEFORE TRUNCATE ON payout_recovery_offsets
    FOR EACH STATEMENT EXECUTE FUNCTION reject_financial_history_change();
CREATE FUNCTION protect_refund_allocation_history() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF TG_OP <> 'UPDATE' THEN
        RAISE EXCEPTION 'Refund allocation history cannot be removed' USING ERRCODE = '23514';
    END IF;
    IF (to_jsonb(NEW) - 'recovered_amount') IS DISTINCT FROM (to_jsonb(OLD) - 'recovered_amount')
        OR NEW.recovered_amount < OLD.recovered_amount OR NEW.recovered_amount > OLD.amount
        OR (NOT OLD.future_recovery AND NEW.recovered_amount <> OLD.recovered_amount) THEN
        RAISE EXCEPTION 'Only bounded monotonic recovery may update an allocation' USING ERRCODE = '23514';
    END IF;
    RETURN NEW;
END $$;
CREATE TRIGGER refund_allocations_history BEFORE UPDATE OR DELETE ON refund_allocations
    FOR EACH ROW EXECUTE FUNCTION protect_refund_allocation_history();
CREATE TRIGGER refund_allocations_no_truncate BEFORE TRUNCATE ON refund_allocations
    FOR EACH STATEMENT EXECUTE FUNCTION reject_financial_history_change();

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012120000_FinancialAuditIntegrity', '8.0.0');

COMMIT;

START TRANSACTION;

DO $$ BEGIN
    IF EXISTS (SELECT 1 FROM "EntrepreneurPayoutBatches"
        WHERE length("Currency") > 10 OR length("Status") > 30
           OR length("PayoutReference") > 200
           OR "TotalAmount" <> round("TotalAmount", 2)
           OR abs("TotalAmount") >= 10000000000000000)
       OR EXISTS (SELECT 1 FROM "EntrepreneurReferralAudits" WHERE length("Reason") > 500)
    THEN RAISE EXCEPTION 'Ledger mapping requires manual review of values exceeding the target precision or length';
    END IF;
END $$;

ALTER TABLE "EntrepreneurReferralAudits" DROP CONSTRAINT "PK_EntrepreneurReferralAudits";

ALTER TABLE "EntrepreneurPayoutBatches" DROP CONSTRAINT "PK_EntrepreneurPayoutBatches";

ALTER TABLE "EntrepreneurReferralAudits" RENAME TO entrepreneur_referral_audits;

ALTER TABLE "EntrepreneurPayoutBatches" RENAME TO entrepreneur_payout_batches;

ALTER TABLE customers RENAME COLUMN "PhoneNumber" TO phone;

ALTER TABLE customer_vehicles RENAME COLUMN "VIN" TO vin;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "Reason" TO reason;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "Id" TO id;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "OldEntrepreneurUserId" TO old_entrepreneur_user_id;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "NewEntrepreneurUserId" TO new_entrepreneur_user_id;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "EntrepreneurReferralId" TO entrepreneur_referral_id;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "ChangedByUserId" TO changed_by_user_id;

ALTER TABLE entrepreneur_referral_audits RENAME COLUMN "ChangedAt" TO changed_at;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "Status" TO status;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "Currency" TO currency;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "Id" TO id;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "TotalAmount" TO total_amount;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "SettlementDate" TO settlement_date;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "ProcessedByUserId" TO processed_by_user_id;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "PayoutReference" TO payout_reference;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "PaidAt" TO paid_at;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "EarningCount" TO earning_count;

ALTER TABLE entrepreneur_payout_batches RENAME COLUMN "CreatedAt" TO created_at;

ALTER TABLE entrepreneur_referral_audits ALTER COLUMN reason TYPE character varying(500);

ALTER TABLE entrepreneur_payout_batches ALTER COLUMN status TYPE character varying(30);

ALTER TABLE entrepreneur_payout_batches ALTER COLUMN currency TYPE character varying(10);

ALTER TABLE entrepreneur_payout_batches ALTER COLUMN total_amount TYPE numeric(18,2);

ALTER TABLE entrepreneur_payout_batches ALTER COLUMN payout_reference TYPE character varying(200);

ALTER TABLE entrepreneur_referral_audits ADD CONSTRAINT "PK_entrepreneur_referral_audits" PRIMARY KEY (id);

ALTER TABLE entrepreneur_payout_batches ADD CONSTRAINT "PK_entrepreneur_payout_batches" PRIMARY KEY (id);

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012120341_AlignAlphaLedgerMappings', '8.0.0');

COMMIT;

START TRANSACTION;

ALTER TABLE payments ADD refund_evidence_conflict boolean NOT NULL DEFAULT FALSE;

-- Old conflict events have order-level audit evidence only. Conservatively hold every payment on those orders.
UPDATE payments p SET refund_evidence_conflict = TRUE
WHERE EXISTS (SELECT 1 FROM order_financials f WHERE f.order_id = p.order_id AND f.financial_status = 'refund_evidence_conflict')
   OR EXISTS (SELECT 1 FROM audit_logs a WHERE a.order_id = p.order_id AND a.action = 'Stripe refund evidence conflict held for manual review');
UPDATE order_financials f SET financial_status = 'refund_evidence_conflict', payout_status = 'on_hold', settlement_status = 'blocked'
WHERE EXISTS (SELECT 1 FROM payments p WHERE p.order_id = f.order_id AND p.refund_evidence_conflict);
UPDATE settlement_queue q SET status = 'on_hold'
WHERE q.status <> 'paid' AND EXISTS (SELECT 1 FROM order_financials f WHERE f.id = q.order_financial_id AND f.financial_status = 'refund_evidence_conflict');
CREATE FUNCTION protect_payment_refund_conflict() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.refund_evidence_conflict THEN
        IF TG_OP = 'DELETE' THEN
            RAISE EXCEPTION 'Conflicting refund evidence requires explicit reviewed resolution' USING ERRCODE = '23514';
        END IF;
        IF NOT NEW.refund_evidence_conflict OR NEW.id IS DISTINCT FROM OLD.id OR NEW.order_id IS DISTINCT FROM OLD.order_id THEN
            RAISE EXCEPTION 'Conflicting refund evidence requires explicit reviewed resolution' USING ERRCODE = '23514';
        END IF;
    END IF;
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
END $$;
CREATE TRIGGER payment_refund_conflict_persistent BEFORE UPDATE OR DELETE ON payments
    FOR EACH ROW EXECUTE FUNCTION protect_payment_refund_conflict();

INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
VALUES ('20261012123720_PreserveRefundEvidenceConflicts', '8.0.0');

COMMIT;

