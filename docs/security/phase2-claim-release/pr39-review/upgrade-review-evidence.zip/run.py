import subprocess,pathlib,os,time,json
root=pathlib.Path('/workspace/work/pr39-upgrade-review');out=root/'evidence';env=os.environ.copy()
for k in list(env):
 if any(s in k.lower() for s in ['database','supabase','jwt','paypal','stripe','paymongo','connectionstrings']):del env[k]
for k in ['DOCKER_HOST','DOCKER_CONTEXT','DOCKER_TLS','DOCKER_TLS_VERIFY','DOCKER_CERT_PATH']:env.pop(k,None)
env.update(DOCKER_HOST='unix:///var/run/docker.sock',PATH='/workspace/.dotnet:'+env['PATH'],DOTNET_ROOT='/workspace/.dotnet',DOTNET_CLI_HOME='/workspace/.dotnet-home',NUGET_PACKAGES='/workspace/.nuget/packages')
results=[]
def run(name,args):
 p=subprocess.run(args,cwd=root,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=600);(out/(name+'.log')).write_text(json.dumps(args)+'\n'+p.stdout);results.append({'check':name,'exitCode':p.returncode});(out/'execution.json').write_text(json.dumps(results,indent=2));print(name,p.returncode,flush=True)
 if p.returncode:raise RuntimeError(p.stdout[-3000:])
container='alpha-pr39-upgrade-review'
try:
 run('docker-start',['docker','run','-d','--name',container,'-p','127.0.0.1:5432:5432','-e','POSTGRES_USER=alpha_ci','-e','POSTGRES_PASSWORD=disposable-ci-only','-e','POSTGRES_DB=alpha_pr39_upgrade','postgres:16@sha256:ca0bd484cb98bf4b24eb1010e73fb3fcbd6714d240fbc1a10eea5b7dbecb641d'])
 for i in range(30):
  if subprocess.run(['docker','exec',container,'pg_isready','-U','alpha_ci'],env=env,stdout=subprocess.DEVNULL).returncode==0:break
  time.sleep(1)
 for name,repo in [('base','phase2-conflict-review'),('candidate','phase2-recovery-release')]:
  run(name+'-identity',['git','-C','/workspace/work/'+repo,'rev-parse','HEAD'])
  run(name+'-restore',['dotnet','restore',str(root/name/'Review.csproj')])
  run(name+'-build',['dotnet','build',str(root/name/'Review.csproj'),'-c','Release','--no-restore','-warnaserror'])
 run('baseline-v1-seed',['dotnet','run','--project',str(root/'base'),'--no-build','--no-restore','-c','Release','--',str(out/'baseline.json')])
 run('candidate-upgrade-review',['dotnet','run','--project',str(root/'candidate'),'--no-build','--no-restore','-c','Release','--',str(out)])
finally:run('cleanup',['docker','rm','-f',container])
