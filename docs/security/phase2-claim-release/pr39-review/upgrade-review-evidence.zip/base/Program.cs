using Alpha.API.Data;
using Alpha.API.Models;
using Alpha.API.Models.Entrepreneur;
using Alpha.API.DTOs;
using Alpha.API.Services;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;

// Fixed synthetic loopback only; no runtime connection/provider bindings are read.
using var db = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>().UseNpgsql(
    "Host=127.0.0.1;Port=5432;Database=alpha_pr39_upgrade;Username=alpha_ci;Password=disposable-ci-only;SSL Mode=Disable").Options);
await db.Database.MigrateAsync();
var migrations = (await db.Database.GetAppliedMigrationsAsync()).ToArray();
if (migrations.Length != 10) throw new InvalidOperationException("Expected the exact PR32 ten-migration baseline.");
var reviewer = Guid.NewGuid();
var ids = new Dictionary<string, Guid> { ["reviewer"] = reviewer };

async Task<(Order Order, Payment Payment, OrderFinancial Financial, SettlementQueue Queue)> OrderFor(Guid payee, bool paid)
{
    var user = new User { Id = Guid.NewGuid(), FullName = "Synthetic rehearsal customer", Email = Guid.NewGuid() + "@example.invalid", Role = "customer", IsActive = true };
    var order = new Order { Id = Guid.NewGuid(), CustomerId = user.Id, OrderNumber = Guid.NewGuid().ToString("N"), CustomerName = "Synthetic", PickupAddress = "Test", DeliveryAddress = "Test", ItemDescription = "Test", Zone = "Test", Status = "waiting_for_supplier", CountryCode = "US", Currency = "USD" };
    var payment = new Payment { Id = Guid.NewGuid(), OrderId = order.Id, Amount = 100, Currency = "USD", PaymentMethod = "paypal", PaymentGateway = "paypal", PaymentStatus = "paid", TransactionReference = "SYNTHETIC-" + Guid.NewGuid() };
    var financial = new OrderFinancial { Id = Guid.NewGuid(), OrderId = order.Id, TotalAmount = 100, CustomerPaid = 100, Currency = "USD", FinancialStatus = "verified", SettlementStatus = "verified", PayoutStatus = paid ? "paid" : "ready_for_payout" };
    var queue = new SettlementQueue { Id = Guid.NewGuid(), OrderFinancialId = financial.Id, PayeeType = "supplier", PayeeId = payee, Amount = paid ? 100 : 50, Status = paid ? "paid" : "ready_for_payout" };
    db.AddRange(user, order, payment, financial, queue);
    if (paid) db.SupplierPayouts.Add(new SupplierPayout { Id = Guid.NewGuid(), SupplierId = payee, OrderId = order.Id, Amount = 100, Currency = "USD", PayoutStatus = "paid", PaidAt = DateTime.UtcNow });
    await db.SaveChangesAsync();
    return (order, payment, financial, queue);
}

foreach (var prefix in new[] { "conflict", "valid" })
{
    var supplier = new Supplier { Id = Guid.NewGuid(), Name = "Synthetic " + prefix + " supplier" };
    db.Add(supplier); await db.SaveChangesAsync();
    var source = await OrderFor(supplier.Id, paid: true);
    var amount = prefix == "conflict" ? 30m : 10m;
    var operation = new PaymentOperation { Id = Guid.NewGuid(), PaymentId = source.Payment.Id, Kind = "refund", State = "completed", Amount = amount, Currency = "USD", IdempotencyKey = Guid.NewGuid().ToString(), ProviderRequestId = Guid.NewGuid().ToString("N"), ProviderReference = "SYNTHETIC-" + Guid.NewGuid(), CreatedAt = DateTime.UtcNow, UpdatedAt = DateTime.UtcNow };
    source.Payment.RefundedAmount = amount; source.Financial.RefundAmount = amount;
    source.Financial.FinancialStatus = "refund_review"; source.Financial.PayoutStatus = "on_hold"; source.Financial.SettlementStatus = "blocked";
    db.Add(operation); await db.SaveChangesAsync();
    await new RefundAllocationService(db).AllocateAsync(operation.Id, new RefundAllocationDto { Evidence = "Synthetic attributable paid supplier", Lines = new() { new() { SourceKind = "settlement", SourceId = source.Queue.Id, Amount = amount } } }, reviewer, CancellationToken.None);
    db.ChangeTracker.Clear();
    if (prefix == "conflict")
    {
        var financial = await db.OrderFinancials.SingleAsync(f => f.Id == source.Financial.Id);
        financial.FinancialStatus = "refund_review"; // Reproduce the old automatically cleared display state.
        db.AuditLogs.Add(new AuditLog { Id = Guid.NewGuid(), OrderId = source.Order.Id, Action = "Stripe refund evidence conflict held for manual review", PerformedBy = "stripe", CreatedAt = DateTime.UtcNow });
        await db.SaveChangesAsync();
    }
    var allocation = await db.Set<RefundAllocation>().SingleAsync(a => a.OperationId == operation.Id && a.FutureRecovery);
    var future = await OrderFor(supplier.Id, paid: false);
    ids[prefix + "Payment"] = source.Payment.Id; ids[prefix + "Order"] = source.Order.Id;
    ids[prefix + "Allocation"] = allocation.Id; ids[prefix + "FutureQueue"] = future.Queue.Id;
    ids[prefix + "FutureOrder"] = future.Order.Id;
}
var batch = new EntrepreneurPayoutBatch { Id = Guid.NewGuid(), SettlementDate = DateTime.UtcNow, TotalAmount = 40.25m, Currency = "USD", EarningCount = 1, Status = "PAID", PayoutReference = "synthetic-baseline-paid-history", CreatedAt = DateTime.UtcNow, PaidAt = DateTime.UtcNow };
db.Add(batch); await db.SaveChangesAsync(); ids["historicalBatch"] = batch.Id;
var first = new User { Id = Guid.NewGuid(), FullName = "Synthetic legacy reviewer", Email = Guid.NewGuid() + "@example.invalid", Role = "admin", IsActive = true };
var second = new User { Id = Guid.NewGuid(), FullName = "Synthetic legacy independent reviewer", Email = Guid.NewGuid() + "@example.invalid", Role = "admin", IsActive = true };
db.AddRange(first, second); await db.SaveChangesAsync();
await db.Payments.Where(p => p.Id == ids["conflictPayment"]).ExecuteUpdateAsync(s => s.SetProperty(p => p.RefundEvidenceConflict, true));
await db.OrderFinancials.Where(f => f.OrderId == ids["conflictOrder"]).ExecuteUpdateAsync(s => s.SetProperty(f => f.FinancialStatus, RefundConflictGuard.Status));
var reviews = new FinancialConflictReviewService(db);
var review = await reviews.SubmitAsync(ids["conflictPayment"], new() { IdempotencyKey = "legacy-v1", Evidence = "Synthetic version-one source review" }, first.Id, default);
await reviews.ApproveAsync(review.Id, new() { Evidence = "Synthetic version-one independent review" }, second.Id, default);
ids["review"] = review.Id; ids["first"] = first.Id; ids["second"] = second.Id;
var result = new { baselineCommit = "442f3ed5c946b08580f0d6934dfa54f2f943cba8", migrations, ids, scope = "Synthetic loopback baseline; no hosted/provider access" };
File.WriteAllText(args[0], JsonSerializer.Serialize(result, new JsonSerializerOptions { WriteIndented = true }));
Console.WriteLine($"BASELINE PASS: {migrations.Length} migrations; synthetic paid history, recovery claims and audited conflict seeded.");
