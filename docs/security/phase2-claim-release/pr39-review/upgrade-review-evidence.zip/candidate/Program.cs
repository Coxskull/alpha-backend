using Alpha.API.Data;
using Alpha.API.Models;
using Alpha.API.Services;
using Microsoft.EntityFrameworkCore;
using System.Text.Json;
var output = args[0]; using var data = JsonDocument.Parse(File.ReadAllText(Path.Combine(output, "baseline.json")));
Guid Id(string key) => data.RootElement.GetProperty("ids").GetProperty(key).GetGuid();
using var db = new AppDbContext(new DbContextOptionsBuilder<AppDbContext>().UseNpgsql("Host=127.0.0.1;Port=5432;Database=alpha_pr39_upgrade;Username=alpha_ci;Password=disposable-ci-only;SSL Mode=Disable").Options);
async Task<string> Snapshot()
{
    var tables = new[] { "payments", "orders", "order_financials", "supplier_payouts", "refund_allocations", "audit_logs", "financial_conflict_reviews", "financial_conflict_approvals", "entrepreneur_payout_batches" };
    var values = new SortedDictionary<string,string>();
    foreach(var table in tables)
    {
        // Identifiers are exclusively from the constant table allowlist above.
#pragma warning disable EF1002
        values[table] = await db.Database.SqlQueryRaw<string>($"SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text), '[]'::jsonb)::text AS \"Value\" FROM {table} t").SingleAsync();
#pragma warning restore EF1002
    }
    return JsonSerializer.Serialize(values);
}
var before = await Snapshot(); await db.Database.MigrateAsync();
if ((await db.Database.GetAppliedMigrationsAsync()).Count()!=11 || before!=await Snapshot()) throw new InvalidOperationException("Upgrade changed existing financial/review records.");
var service = new FinancialConflictReviewService(db); var reviewId=Id("review");
var status = JsonSerializer.SerializeToElement(await service.StatusAsync(reviewId, default));
if(status.GetProperty("status").GetString()!="evidence_changed") throw new InvalidOperationException("Legacy version-one review did not become stale.");
var claimId=Id("conflictAllocation");
try { await new FinancialRecoveryReleaseService(db).ReleaseAsync(reviewId,new(){AllocationId=claimId,Evidence="Old evidence must not authorize release"},Id("second"),default);throw new Exception("Stale review authorized recovery."); }
catch(InvalidOperationException ex) when(ex.Message.Contains("fresh review")) { }
if(await db.Set<FinancialRecoveryRelease>().AnyAsync()) throw new Exception("Stale attempt persisted a release.");
var fresh=await service.SubmitAsync(Id("conflictPayment"),new(){IdempotencyKey="fresh-v2",Evidence="Fresh version-two source review"},Id("first"),default);
await service.ApproveAsync(fresh.Id,new(){Evidence="Fresh version-two independent review"},Id("second"),default);
await new FinancialRecoveryReleaseService(db).ReleaseAsync(fresh.Id,new(){AllocationId=claimId,Evidence="Reviewed existing-claim release only"},Id("second"),default);
using(var tx=await db.Database.BeginTransactionAsync())
{
 var claim=await db.Set<RefundAllocation>().AsNoTracking().SingleAsync(x=>x.Id==claimId);
 var recovered=await new RefundAllocationService(db).RecoverAsync(claim.PayeeType,claim.PayeeId,claim.Currency,"settlement",Guid.NewGuid(),50,default);
 if(recovered!=30) throw new Exception("Fresh review failed bounded recovery.");
 await db.SaveChangesAsync();await tx.CommitAsync();
}
if(!await RefundConflictGuard.HasAsync(db,Id("conflictOrder"),default))throw new Exception("Original hold was cleared.");
File.WriteAllText(Path.Combine(output,"upgrade-review-result.json"),JsonSerializer.Serialize(new { upgrade="PASS",migrations=11,existingMoneyAndV1RecordsUnchanged=true,oldAttestations="STALE",staleRelease="REJECTED_NO_RECORD",freshV2Attestations="PASS",boundedSyntheticRecovery=30,originalOrderHold="RETAINED",scope="Disposable synthetic local upgrade only; no bank/provider transfers"},new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine("PASS: legacy evidence preserved/stale; fresh two-admin review permits bounded claim recovery with original hold retained.");
