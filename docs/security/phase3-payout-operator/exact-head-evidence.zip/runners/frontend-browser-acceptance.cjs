const {chromium}=require('/workspace/work/browser-tools/node_modules/playwright');
const assert=require('node:assert/strict');const fs=require('node:fs');
const out='/workspace/work/phase3-frontend-evidence';
const id='00000000-0000-4000-8000-000000000001';const earning='00000000-0000-4000-8000-000000000002';
const baseQuote={settlementId:id,status:'quote',currency:'USD',grossAmount:50,refundAdjustment:0,payableBeforeRecovery:50,recoveryOffset:30,paidAmount:20,netAmount:20,remainingRecoveryBalance:0,zeroNet:false,quoteIsAdvisory:true,confirmationRequired:true,eligibleForConfirmation:true};
const queue={id,orderFinancialId:id,payeeType:'supplier',payeeId:id,amount:50,status:'ready_for_payout',createdAt:'2026-10-13T00:00:00Z',financial:{orderId:id,currency:'USD',customerPaid:100,taxCollected:0,taxWithheld:0,processingFee:0,alphaNetRevenue:0,reconciliationDifference:0,financialStatus:'verified',settlementStatus:'verified',payoutStatus:'ready_for_payout'}};
(async()=>{
 const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox','--disable-background-networking']});const results=[];
 async function scenario(name,options,body){
  const context=await browser.newContext({viewport:{width:1200,height:900}});let posts=[];let quote={...baseQuote,...options.quote};let paid=false;let changed=false;const errors=[];
  await context.addInitScript(role=>{localStorage.setItem('alpha_token','synthetic-browser-token');localStorage.setItem('alpha_user',JSON.stringify({id:'synthetic-admin',fullName:'Synthetic operator',role,roles:[role],isActive:true}));},options.role||'admin');
  await context.route('**/*',async route=>{
   const req=route.request();const u=new URL(req.url());
   if(u.origin==='http://127.0.0.1:5127')return route.continue();
   if(u.origin!=='http://127.0.0.1:59999')return route.abort();
   const headers={'access-control-allow-origin':'*','access-control-allow-headers':'authorization,content-type','access-control-allow-methods':'GET,POST,OPTIONS'};
   const reply=(data,status=200)=>route.fulfill({status,contentType:'application/json',headers,body:JSON.stringify(data)});
   if(req.method()==='OPTIONS')return reply({});
   assert.equal(req.headers()['authorization'],'Bearer synthetic-browser-token');
   if(u.pathname==='/api/Auth/me')return reply({user:{id:'synthetic-admin',fullName:'Synthetic operator',role:options.role||'admin',roles:[options.role||'admin'],roleStatuses:[{role:options.role||'admin',status:'active'}],isActive:true}});
   if(u.pathname.endsWith('/mark-paid')){
    posts.push(JSON.parse(req.postData()));
    if(options.stale&&!changed){changed=true;quote={...baseQuote,recoveryOffset:0,netAmount:50,paidAmount:50};return reply({code:'payout_quote_changed',message:'Refresh current net quote'},409);}
    paid=true;if(options.unknown)return route.abort('failed');return reply({...quote,status:'paid'});
   }
   if(u.pathname.endsWith('/quote')||u.pathname.endsWith('/payout-quote')){
    if(options.denied)return reply({message:'Administrator access required'},403);
    if(options.held)return reply({code:'payout_review_required',message:'Payout held for source evidence'},409);
    if(paid)return reply({settlementId:id,earningId:earning,paidAmount:quote.paidAmount,currency:'USD',status:'paid'});
    return reply(quote);
   }
   if(u.pathname.endsWith('/settlement-queue'))return reply([{...queue,status:paid?'paid':'ready_for_payout'}]);
   if(u.pathname.endsWith('/pending-settlements'))return reply([]);
   if(u.pathname==='/api/admin/entrepreneur/earnings')return reply([{id:earning,currency:'USD',earningStatus:'APPROVED'}]);
   return reply({});
  });
  const page=await context.newPage();page.on('pageerror',e=>errors.push(e.message));
  try{await page.goto('http://127.0.0.1:5127'+(options.path||'/mission-control/financials'));await page.getByRole('button',{name:'Review payout',exact:true}).first().click();await page.getByRole('dialog').waitFor();
   await body(page,posts);assert.deepEqual(errors,[]);results.push({name,result:'PASS',posts:posts.length});
  }catch(e){results.push({name,result:'FAIL',error:String(e)});throw e;}finally{await context.close();fs.writeFileSync(out+'/browser-results.json',JSON.stringify(results,null,2));}
 }
 try{
  await scenario('Exact net/currency/reference required; gross cannot be posted',{},async(page,posts)=>{
   await page.getByLabel('Confirmed net amount').waitFor();await page.getByLabel('Confirmed net amount').fill('50');await page.getByLabel('Payout reference',{exact:true}).fill('synthetic-reviewed-ref');await page.getByRole('checkbox').check();assert.equal(await page.getByRole('button',{name:'Record reviewed payout',exact:true}).isDisabled(),true);
   await page.getByLabel('Confirmed net amount').fill('20');assert.equal(await page.getByLabel('Confirmed net amount').evaluate(e=>getComputedStyle(e).backgroundColor),'rgb(255, 255, 255)'); assert.equal(await page.getByRole('checkbox').evaluate(e=>e.getBoundingClientRect().width),16); assert.equal(await page.getByRole('button',{name:'Record reviewed payout',exact:true}).evaluate(e=>getComputedStyle(e).color),'rgb(255, 255, 255)'); await page.screenshot({path:out+'/payout-review.png'});await page.getByRole('button',{name:'Record reviewed payout',exact:true}).click();await page.getByText('Reviewed payout recorded successfully.').waitFor();assert.deepEqual(posts,[{paidAmount:20,currency:'USD',payoutReference:'synthetic-reviewed-ref'}]);
  });
  await scenario('Zero net and carry-forward record explicit zero', {quote:{recoveryOffset:50,paidAmount:0,netAmount:0,remainingRecoveryBalance:10,zeroNet:true}},async(page,posts)=>{
   await page.getByText(/No cash payout/).waitFor();await page.getByLabel('Confirmed net amount').fill('0');await page.getByLabel('Payout reference',{exact:true}).fill('synthetic-zero-offset');await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Record zero-cash offset',exact:true}).click();await page.getByText('Reviewed payout recorded successfully.').waitFor();assert.equal(posts[0].paidAmount,0);
  });
  await scenario('Changed quote requires refresh and a new explicit decision',{stale:true,path:'/mission-control/settlement-queue'},async(page,posts)=>{
   await page.getByLabel('Confirmed net amount').waitFor();await page.getByLabel('Confirmed net amount').fill('20');await page.getByLabel('Payout reference',{exact:true}).fill('synthetic-stale-ref');await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Record reviewed payout',exact:true}).click();await page.getByText(/payout quote changed/).waitFor();assert.equal(posts.length,1);
   await page.getByRole('button',{name:'Refresh payout preview'}).click();await page.getByLabel('Confirmed net amount').waitFor();assert.equal(await page.getByLabel('Confirmed net amount').inputValue(),'');assert.equal(await page.getByRole('checkbox').isChecked(),false);assert.equal(await page.getByLabel('Payout reference',{exact:true}).inputValue(),'synthetic-stale-ref');await page.getByLabel('Confirmed net amount').fill('50');await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Record reviewed payout',exact:true}).click();await page.getByText('Reviewed payout recorded successfully.').waitFor();assert.equal(posts.length,2);assert.equal(posts[1].paidAmount,50);
  });
  await scenario('Held payout cannot be confirmed',{held:true},async(page,posts)=>{await page.getByText('Payout held for source evidence').waitFor();assert.equal(await page.getByLabel('Confirmed net amount').count(),0);assert.equal(posts.length,0);});
  await scenario('Dispatcher quote denial cannot enable confirmation',{role:'dispatcher',denied:true},async(page,posts)=>{await page.getByText('Administrator access is required to review payouts.').waitFor();assert.equal(await page.getByLabel('Confirmed net amount').count(),0);assert.equal(posts.length,0);});
  await scenario('Unknown POST outcome reconciles as already recorded without repeat',{unknown:true},async(page,posts)=>{
   await page.getByLabel('Confirmed net amount').waitFor();await page.getByLabel('Confirmed net amount').fill('20');await page.getByLabel('Payout reference',{exact:true}).fill('synthetic-unknown-ref');await page.getByRole('checkbox').check();await page.getByRole('button',{name:'Record reviewed payout',exact:true}).click();await page.getByText(/Confirmation outcome is unknown/).waitFor();assert.equal(posts.length,1);await page.getByRole('button',{name:'Refresh payout preview'}).click();await page.getByText(/already recorded/).waitFor();assert.equal(posts.length,1);
  });
  await scenario('Mobile dialog fits and keyboard focus remains inside',{},async(page,posts)=>{
   await page.setViewportSize({width:390,height:844}); await page.getByLabel('Confirmed net amount').waitFor();
   const modal=page.getByRole('dialog');assert.ok((await modal.boundingBox()).width<=390);
   await page.getByRole('button',{name:'Refresh payout preview'}).focus();await page.keyboard.press('Tab');assert.equal(await page.getByRole('button',{name:'Close payout review'}).evaluate(e=>document.activeElement===e),true);
   await page.keyboard.press('Escape');await modal.waitFor({state:'detached'});assert.equal(posts.length,0);
  });
  await scenario('Entrepreneur threshold blocks confirmation',{path:'/mission-control/entrepreneur/payouts',quote:{settlementId:undefined,earningId:earning,grossAmount:40,chargebackAdjustment:0,payableBeforeRecovery:40,recoveryOffset:0,paidAmount:40,netAmount:40,minimumPayoutThreshold:50,eligibleForConfirmation:false,blockedReasonCode:'payout_threshold_not_met'}},async(page,posts)=>{await page.getByText(/below the configured minimum/).waitFor();assert.equal(await page.getByRole('button',{name:'Record reviewed payout',exact:true}).isDisabled(),true);assert.equal(posts.length,0);});
 }finally{await browser.close();}
 console.log(JSON.stringify(results,null,2));
})().catch(e=>{console.error(e);process.exit(1)});
