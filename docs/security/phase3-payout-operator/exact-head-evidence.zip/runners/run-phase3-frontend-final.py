import os,subprocess,pathlib,glob,json,time,urllib.request
root=pathlib.Path('/workspace/work/phase3-frontend/alpha-frontend');out=pathlib.Path('/workspace/work/phase3-frontend-evidence');env=os.environ.copy()
for k in list(env):
 if any(x in k.lower() for x in ['database','supabase','jwt','paypal','stripe','paymongo','connectionstrings','next_public']):del env[k]
node=glob.glob('/workspace/work/npm-cache/_npx/*/node_modules/node/bin/node')[0];env.update(PATH=str(pathlib.Path(node).parent)+':'+env['PATH'],NEXT_PUBLIC_API_URL='http://127.0.0.1:59999',NEXT_TELEMETRY_DISABLED='1',NPM_CONFIG_CACHE='/workspace/work/npm-cache')
results=[]
def run(name,args,allow_failure=False):
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 results.append({'check':name,'exitCode':r.returncode});(out/'execution.json').write_text(json.dumps(results,indent=2));print(name,r.returncode,flush=True)
 if r.returncode and not allow_failure:raise RuntimeError(name)
run('exact-identity',['git','rev-parse','HEAD']);run('node-version',[node,'--version'])
run('typecheck-final',[node,'node_modules/typescript/bin/tsc','--noEmit'])
run('changed-lint-final',[node,'node_modules/eslint/bin/eslint.js','components/financials/PayoutReview.tsx','lib/payoutQuote.ts','tests/payoutQuote.test.ts','services/payouts.ts','services/financials.ts','app/mission-control/financials/page.tsx','app/mission-control/settlement-queue/page.tsx','app/mission-control/entrepreneur/page.tsx','app/mission-control/entrepreneur/payouts/page.tsx'])
run('contract-test-build',[node,'node_modules/typescript/bin/tsc','lib/payoutQuote.ts','tests/payoutQuote.test.ts','--outDir','/workspace/work/frontend-test-build','--module','commonjs','--moduleResolution','node','--target','es2020','--esModuleInterop','--skipLibCheck'])
run('contract-tests',[node,'--test','/workspace/work/frontend-test-build/tests/payoutQuote.test.js'])
run('production-audit',['npm','audit','--omit=dev','--json'],allow_failure=True)
run('build-node20',['npm','run','build'])
log=(out/'server.log').open('w');server=subprocess.Popen([node,'node_modules/next/dist/bin/next','start','--hostname','127.0.0.1','--port','5127'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
try:
 for i in range(60):
  try:urllib.request.urlopen('http://127.0.0.1:5127',timeout=1);break
  except Exception:time.sleep(0.5)
 run('browser',[node,'/workspace/work/frontend-browser-acceptance.cjs'])
finally:server.terminate();server.wait(timeout=20);log.close()
